from __future__ import annotations

import hashlib
from pathlib import Path

import imagehash
import pandas as pd
from PIL import Image
from tqdm import tqdm

from a2t_rank.data.schema import ATTRIBUTE_COLUMNS, MASK_COLUMNS, OFFICIAL_COLUMN_MAP
from a2t_rank.utils import sha256_file


def stable_sample_id(relative_path: str) -> str:
    return hashlib.sha256(relative_path.encode("utf-8")).hexdigest()[:24]


def inspect_image(path: Path) -> tuple[bool, str, str]:
    if not path.is_file():
        return False, "", ""
    try:
        file_hash = sha256_file(path)
        with Image.open(path) as image:
            image.load()
            perceptual = str(imagehash.phash(image.convert("RGB")))
        return True, file_hash, perceptual
    except (OSError, ValueError):
        return False, "", ""


def prepare_apddv2(annotations: Path, image_root: Path, output: Path) -> pd.DataFrame:
    table = pd.read_csv(annotations).rename(columns=OFFICIAL_COLUMN_MAP)
    missing = [name for name in OFFICIAL_COLUMN_MAP.values() if name not in table.columns]
    if missing:
        raise ValueError(f"Official annotation fields are missing after normalization: {missing}")

    table["relative_path"] = table["relative_path"].astype(str)
    table["sample_id"] = table["relative_path"].map(stable_sample_id)
    table["total_score"] = pd.to_numeric(table["total_score_source"], errors="raise") / 10.0
    table["category"] = table["category"].astype(str)

    for attribute, mask in zip(ATTRIBUTE_COLUMNS, MASK_COLUMNS, strict=True):
        table[attribute] = pd.to_numeric(table[attribute], errors="coerce")
        table[mask] = table[attribute].notna().astype("int8")

    decoded: list[bool] = []
    hashes: list[str] = []
    phashes: list[str] = []
    for relative_path in tqdm(table["relative_path"], desc="Inspecting images"):
        ok, file_hash, perceptual = inspect_image(image_root / relative_path)
        decoded.append(ok)
        hashes.append(file_hash)
        phashes.append(perceptual)

    table["decode_ok"] = decoded
    table["sha256"] = hashes
    table["phash"] = phashes
    for column in ("source_url", "artist", "title", "group_id"):
        if column not in table:
            table[column] = ""
    table["duplicate_audit_complete"] = False

    ordered = [
        "sample_id",
        "relative_path",
        "total_score",
        "category",
        *ATTRIBUTE_COLUMNS,
        *MASK_COLUMNS,
        "sha256",
        "phash",
        "decode_ok",
        "source_url",
        "artist",
        "title",
        "group_id",
        "duplicate_audit_complete",
    ]
    output.parent.mkdir(parents=True, exist_ok=True)
    table[ordered].to_csv(output, index=False)
    return table[ordered]
