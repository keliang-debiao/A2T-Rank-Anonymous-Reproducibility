from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np
import torch
import torch.nn.functional as F


@dataclass(frozen=True)
class AffineCalibration:
    mean_scale: float
    mean_bias: float
    logvar_scale_raw: float
    logvar_bias: float

    @property
    def logvar_scale(self) -> float:
        return float(F.softplus(torch.tensor(self.logvar_scale_raw)).item())

    def to_dict(self) -> dict[str, float]:
        result = asdict(self)
        result["logvar_scale"] = self.logvar_scale
        return result


def fit_affine_calibration(
    target: np.ndarray,
    mean: np.ndarray,
    logvar: np.ndarray,
    maximum_iterations: int = 500,
) -> AffineCalibration:
    target_tensor = torch.as_tensor(target, dtype=torch.float64)
    mean_tensor = torch.as_tensor(mean, dtype=torch.float64)
    logvar_tensor = torch.as_tensor(logvar, dtype=torch.float64)
    parameters = torch.nn.Parameter(
        torch.tensor([1.0, 0.0, 0.5413248546, 0.0], dtype=torch.float64)
    )
    optimizer = torch.optim.LBFGS(
        [parameters],
        lr=0.25,
        max_iter=maximum_iterations,
        tolerance_grad=1e-10,
        tolerance_change=1e-12,
        line_search_fn="strong_wolfe",
    )

    def closure() -> torch.Tensor:
        optimizer.zero_grad(set_to_none=True)
        calibrated_mean = parameters[0] * mean_tensor + parameters[1]
        calibrated_logvar = parameters[3] + F.softplus(parameters[2]) * logvar_tensor
        loss = (
            0.5
            * (
                torch.exp(-calibrated_logvar) * (target_tensor - calibrated_mean).square()
                + calibrated_logvar
            ).mean()
        )
        loss.backward()
        return loss

    optimizer.step(closure)
    values = parameters.detach().cpu().numpy()
    return AffineCalibration(*map(float, values))


def apply_affine_calibration(
    mean: np.ndarray,
    logvar: np.ndarray,
    calibration: AffineCalibration,
) -> tuple[np.ndarray, np.ndarray]:
    calibrated_mean = calibration.mean_scale * np.asarray(mean) + calibration.mean_bias
    calibrated_logvar = calibration.logvar_bias + calibration.logvar_scale * np.asarray(logvar)
    return calibrated_mean, calibrated_logvar
