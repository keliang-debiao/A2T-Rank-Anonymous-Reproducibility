from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

import pandas as pd
import torch
import yaml
from torch.utils.data import DataLoader

from a2t_rank.calibration import apply_affine_calibration, fit_affine_calibration
from a2t_rank.data.dataset import APDDv2Dataset, category_mapping, load_partition
from a2t_rank.losses import compute_losses
from a2t_rank.metrics import gaussian_calibration_metrics, regression_metrics
from a2t_rank.models import A2TRank
from a2t_rank.prediction import predict_loader, save_predictions
from a2t_rank.utils import seed_everything, sha256_file, write_json


class JsonlLogger:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.path.write_text("", encoding="utf-8")

    def write(self, value: dict[str, object]) -> None:
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(value, sort_keys=True) + "\n")


def _worker_seed(worker_id: int) -> None:
    worker_seed = torch.initial_seed() % 2**32
    import random

    import numpy as np

    random.seed(worker_seed + worker_id)
    np.random.seed(worker_seed + worker_id)


def _load_prompt_bank(path: Path) -> torch.Tensor:
    payload = torch.load(path, map_location="cpu", weights_only=True)
    prompt_bank = payload["queries"] if isinstance(payload, dict) else payload
    if tuple(prompt_bank.shape) != (10, 512):
        raise ValueError(f"Prompt bank must have shape (10, 512), found {tuple(prompt_bank.shape)}")
    return prompt_bank


def _make_loaders(
    config: dict[str, Any],
    fold: int,
    seed: int,
) -> tuple[DataLoader, DataLoader, DataLoader, dict[str, int]]:
    data = config["data"]
    manifest_path = Path(data["manifest"])
    split_path = Path(data["split_dir"]) / f"outer_fold_{fold}.csv"
    manifest = pd.read_csv(manifest_path)
    categories = category_mapping(manifest)
    tables = {
        role: load_partition(manifest_path, split_path, role)
        for role in ("train", "validation", "test")
    }
    image_root = Path(data["image_root"])
    size = int(config["experiment"]["image_size"])
    datasets = {
        role: APDDv2Dataset(
            table,
            image_root,
            categories,
            training=role == "train",
            image_size=size,
        )
        for role, table in tables.items()
    }
    generator = torch.Generator().manual_seed(seed)
    workers = int(config["train"]["num_workers"])
    common = {
        "batch_size": int(config["train"]["batch_size"]),
        "num_workers": workers,
        "pin_memory": True,
        "worker_init_fn": _worker_seed,
        "persistent_workers": workers > 0,
    }
    train_loader = DataLoader(datasets["train"], shuffle=True, generator=generator, **common)
    validation_loader = DataLoader(datasets["validation"], shuffle=False, **common)
    test_loader = DataLoader(datasets["test"], shuffle=False, **common)
    return train_loader, validation_loader, test_loader, categories


def _optimizer(model: torch.nn.Module, config: dict[str, Any]) -> torch.optim.Optimizer:
    lora = []
    modules = []
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        if ".lora_" in name:
            lora.append(parameter)
        else:
            modules.append(parameter)
    groups = [
        {"params": lora, "lr": float(config["train"]["visual_lora_lr"])},
        {"params": modules, "lr": float(config["train"]["module_lr"])},
    ]
    return torch.optim.AdamW(groups, weight_decay=float(config["train"]["weight_decay"]))


def _scheduler(
    optimizer: torch.optim.Optimizer,
    total_steps: int,
    warmup_steps: int,
) -> torch.optim.lr_scheduler.LambdaLR:
    def multiplier(step: int) -> float:
        if step < warmup_steps:
            return max(1e-8, (step + 1) / max(1, warmup_steps))
        progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
        return 0.5 * (1.0 + math.cos(math.pi * min(1.0, progress)))

    return torch.optim.lr_scheduler.LambdaLR(optimizer, multiplier)


def _move_batch(batch: dict[str, object], device: torch.device) -> dict[str, object]:
    return {
        key: value.to(device, non_blocking=True) if isinstance(value, torch.Tensor) else value
        for key, value in batch.items()
    }


def train_seed_fold(config: dict[str, Any], seed: int, fold: int) -> dict[str, object]:
    seed_everything(seed, bool(config["train"]["deterministic"]))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    run_name = f"seed{seed}_fold{fold}"
    root = Path(config["output"]["root"])
    run_dir = root / "runs" / run_name
    checkpoint_dir = root / "checkpoints" / run_name
    prediction_dir = root / "predictions"
    calibration_dir = root / "calibration"
    metric_dir = root / "metrics"
    for directory in (run_dir, checkpoint_dir, prediction_dir, calibration_dir, metric_dir):
        directory.mkdir(parents=True, exist_ok=True)
    with (run_dir / "config.yaml").open("w", encoding="utf-8") as handle:
        yaml.safe_dump(config, handle, sort_keys=True)
    logger = JsonlLogger(root / "runtime_logs" / f"{run_name}.jsonl")
    logger.write(
        {
            "event": "run_started",
            "seed": seed,
            "fold": fold,
            "device_type": device.type,
            "torch_version": torch.__version__,
        }
    )

    train_loader, validation_loader, test_loader, categories = _make_loaders(config, fold, seed)
    write_json(run_dir / "category_mapping.json", categories)
    prompt_bank = _load_prompt_bank(Path(config["data"]["prompt_bank"]))
    model = A2TRank(config, prompt_bank).to(device)
    optimizer = _optimizer(model, config)
    accumulation = int(config["train"]["gradient_accumulation"])
    updates_per_epoch = math.ceil(len(train_loader) / accumulation)
    epochs = int(config["train"]["epochs"])
    scheduler = _scheduler(
        optimizer,
        total_steps=updates_per_epoch * epochs,
        warmup_steps=updates_per_epoch * int(config["train"]["warmup_epochs"]),
    )
    scaler = torch.amp.GradScaler(
        "cuda", enabled=bool(config["train"]["amp"]) and device.type == "cuda"
    )
    amp_enabled = bool(config["train"]["amp"]) and device.type == "cuda"
    best_srocc = -float("inf")
    best_epoch = 0
    patience = 0
    checkpoint_path = checkpoint_dir / "best.pt"

    for epoch in range(1, epochs + 1):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        running: dict[str, float] = {}
        batches = 0
        for batch_index, raw_batch in enumerate(train_loader, start=1):
            batch = _move_batch(raw_batch, device)
            with torch.autocast(device_type=device.type, enabled=amp_enabled):
                outputs = model(batch["image"])
                total_loss, terms = compute_losses(outputs, batch, config)
                scaled_loss = total_loss / accumulation
            scaler.scale(scaled_loss).backward()
            should_step = batch_index % accumulation == 0 or batch_index == len(train_loader)
            if should_step:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(
                    model.parameters(), float(config["train"]["gradient_clip_norm"])
                )
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad(set_to_none=True)
                scheduler.step()
            running["total"] = running.get("total", 0.0) + float(total_loss.detach())
            for name, value in terms.items():
                running[name] = running.get(name, 0.0) + float(value.detach())
            batches += 1

        validation = predict_loader(model, validation_loader, device, amp_enabled)
        validation_metrics = regression_metrics(validation["y_true"], validation["y_pred"])
        epoch_record = {
            "event": "epoch_completed",
            "epoch": epoch,
            "train": {name: value / batches for name, value in running.items()},
            "validation": validation_metrics,
            "learning_rates": [group["lr"] for group in optimizer.param_groups],
        }
        logger.write(epoch_record)
        if validation_metrics["srocc"] > best_srocc:
            best_srocc = validation_metrics["srocc"]
            best_epoch = epoch
            patience = 0
            torch.save(
                {
                    "epoch": epoch,
                    "seed": seed,
                    "fold": fold,
                    "model_state": model.state_dict(),
                    "optimizer_state": optimizer.state_dict(),
                    "scheduler_state": scheduler.state_dict(),
                    "validation_metrics": validation_metrics,
                },
                checkpoint_path,
            )
        else:
            patience += 1
            if patience >= int(config["train"]["early_stopping_patience"]):
                logger.write({"event": "early_stopping", "epoch": epoch, "best_epoch": best_epoch})
                break

    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model_state"])
    validation = predict_loader(model, validation_loader, device, amp_enabled)
    test = predict_loader(model, test_loader, device, amp_enabled)
    validation_path = prediction_dir / f"inner_{run_name}.csv"
    test_path = prediction_dir / f"outer_{run_name}.csv"
    save_predictions(validation, validation_path)

    calibration = fit_affine_calibration(
        validation["y_true"].to_numpy(),
        validation["y_pred"].to_numpy(),
        validation["logvar"].to_numpy(),
    )
    calibrated_mean, calibrated_logvar = apply_affine_calibration(
        test["y_pred"].to_numpy(), test["logvar"].to_numpy(), calibration
    )
    test["y_pred_cal"] = calibrated_mean
    test["logvar_cal"] = calibrated_logvar
    save_predictions(test, test_path)
    calibration_path = calibration_dir / f"{run_name}.json"
    write_json(calibration_path, calibration.to_dict())

    raw_metrics = regression_metrics(test["y_true"], test["y_pred"])
    calibrated_metrics = regression_metrics(test["y_true"], test["y_pred_cal"])
    uncertainty_metrics = gaussian_calibration_metrics(
        test["y_true"].to_numpy(),
        test["y_pred_cal"].to_numpy(),
        test["logvar_cal"].to_numpy(),
    )
    summary = {
        "status": "executed",
        "seed": seed,
        "fold": fold,
        "best_epoch": best_epoch,
        "checkpoint_sha256": sha256_file(checkpoint_path),
        "prompt_bank_sha256": sha256_file(Path(config["data"]["prompt_bank"])),
        "raw": raw_metrics,
        "calibrated": calibrated_metrics,
        "uncertainty": uncertainty_metrics,
    }
    write_json(metric_dir / f"{run_name}.json", summary)
    logger.write({"event": "run_completed", **summary})
    return summary
