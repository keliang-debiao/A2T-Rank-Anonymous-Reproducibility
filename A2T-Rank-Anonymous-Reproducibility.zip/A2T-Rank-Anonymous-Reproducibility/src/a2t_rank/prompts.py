from __future__ import annotations

ATTRIBUTE_NAMES = (
    "Theme and Logic",
    "Creativity",
    "Layout and Composition",
    "Space and Perspective",
    "Sense of Order",
    "Light and Shadow",
    "Color",
    "Details and Texture",
    "Mood",
    "The Overall",
)

TRANSFER_ATTRIBUTE_COUNT = 9
OVERALL_INDEX = 9

PROMPT_PAIRS = (
    (
        "a coherent artwork with a clear theme and internally consistent visual logic",
        "an incoherent artwork with an unclear theme and contradictory visual logic",
    ),
    (
        "an inventive artwork with original ideas and non-routine artistic choices",
        "a derivative artwork with conventional ideas and little originality",
    ),
    (
        "an artwork with balanced layout, purposeful composition, and effective visual hierarchy",
        "an artwork with unbalanced layout, weak composition, and confused visual hierarchy",
    ),
    (
        "an artwork with convincing spatial organization, depth, and perspective",
        "an artwork with flat or inconsistent space, depth, and perspective",
    ),
    (
        "an artwork with deliberate visual order, rhythm, and organized relationships",
        "an artwork with disordered visual rhythm and poorly organized relationships",
    ),
    (
        "an artwork with expressive, coherent, and well-controlled light and shadow",
        "an artwork with inconsistent, ineffective, or poorly controlled light and shadow",
    ),
    (
        "an artwork with harmonious, purposeful, and expressive color relationships",
        "an artwork with discordant, arbitrary, or ineffective color relationships",
    ),
    (
        "an artwork with purposeful detail, material richness, and convincing texture",
        "an artwork with careless detail, weak material description, and unconvincing texture",
    ),
    (
        "an artwork with a coherent and evocative emotional atmosphere",
        "an artwork with an unclear or emotionally inconsistent atmosphere",
    ),
    (
        "an artwork with strong overall integrity and a unified aesthetic impression",
        "an artwork with weak overall integrity and a fragmented aesthetic impression",
    ),
)


def validate_prompt_bank() -> None:
    if len(ATTRIBUTE_NAMES) != 10 or len(PROMPT_PAIRS) != 10:
        raise RuntimeError("The frozen prompt bank must contain exactly ten attributes")
    if ATTRIBUTE_NAMES[OVERALL_INDEX] != "The Overall":
        raise RuntimeError("The diagnostic attribute must remain at index 9")
