from __future__ import annotations

import numpy as np
import pandas as pd

from a2t_rank.data.splits import assert_group_disjoint, build_nested_splits


def test_nested_splits_are_group_disjoint(tmp_path) -> None:
    rows = []
    for index in range(240):
        rows.append(
            {
                "sample_id": f"s{index:04d}",
                "group_id": f"g{index // 2:04d}",
                "category": f"c{index % 24:02d}",
                "total_score": float(1 + (index % 90) / 10),
                "duplicate_audit_complete": True,
            }
        )
    table = pd.DataFrame(rows)
    paths = build_nested_splits(table, tmp_path, seed=2026)
    assert len(paths) == 5
    test_ids = []
    for path in paths:
        split = pd.read_csv(path)
        assert_group_disjoint(split)
        test_ids.extend(split.loc[split["role"] == "test", "sample_id"])
    values, counts = np.unique(test_ids, return_counts=True)
    assert len(values) == len(table)
    assert set(counts) == {1}
