from __future__ import annotations

from pathlib import Path

import torch

from a2t_rank.config import load_yaml
from a2t_rank.losses import compute_losses
from a2t_rank.models import A2TRankCore


def test_core_shapes_and_overall_exclusion() -> None:
    config = load_yaml(Path("configs/a2t_rank.yaml"))
    prompt_bank = torch.randn(10, 512)
    model = A2TRankCore(config, prompt_bank)
    batch_size = 2
    outputs = model(
        torch.randn(batch_size, 576, 1024),
        torch.randn(batch_size, 1024),
        torch.randn(batch_size, 121, 1024),
        torch.randn(batch_size, 1024),
    )
    assert outputs["mean"].shape == (batch_size,)
    assert outputs["logvar"].shape == (batch_size,)
    assert outputs["attributes"].shape == (batch_size, 10)
    assert outputs["reliability"].shape == (batch_size, 9)
    assert outputs["aggregation"].shape == (batch_size, 9)
    assert torch.allclose(outputs["aggregation"].sum(dim=1), torch.ones(batch_size), atol=1e-6)


def test_loss_is_finite_with_missing_attributes() -> None:
    config = load_yaml(Path("configs/a2t_rank.yaml"))
    prompt_bank = torch.randn(10, 512)
    model = A2TRankCore(config, prompt_bank)
    outputs = model(
        torch.randn(3, 576, 1024),
        torch.randn(3, 1024),
        torch.randn(3, 121, 1024),
        torch.randn(3, 1024),
    )
    batch = {
        "target": torch.tensor([4.0, 6.0, 8.0]),
        "attributes": torch.rand(3, 10) * 10,
        "attribute_mask": torch.tensor([[1, 0, 1, 1, 1, 0, 1, 1, 1, 1]] * 3, dtype=torch.float32),
        "category": torch.tensor([0, 1, 2]),
    }
    total, terms = compute_losses(outputs, batch, config)
    assert torch.isfinite(total)
    assert set(terms) == {
        "main",
        "attribute",
        "rank",
        "prompt",
        "reliability",
        "category",
        "adversarial",
        "orthogonality",
        "uncertainty",
    }
