from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold


def stratification_labels(table: pd.DataFrame) -> np.ndarray:
    return table["category"].astype(str).to_numpy()


def _split_inner(
    development: pd.DataFrame,
    seed: int,
    validation_fraction: float = 0.10,
) -> set[str]:
    groups = development.groupby("group_id", sort=True)
    group_rows = groups.agg(
        size=("sample_id", "size"),
        category=("category", lambda x: x.mode().iat[0]),
        score=("total_score", "mean"),
    ).reset_index()
    group_rows["score_bin"] = pd.qcut(group_rows["score"], q=10, labels=False, duplicates="drop")
    rng = np.random.default_rng(seed)
    selected: list[str] = []
    target = round(len(development) * validation_fraction)
    for _, stratum in group_rows.groupby(["category", "score_bin"], dropna=False):
        indices = rng.permutation(len(stratum))
        stratum_target = max(1, round(stratum["size"].sum() * validation_fraction))
        running = 0
        for position in indices:
            row = stratum.iloc[int(position)]
            if running >= stratum_target:
                break
            selected.append(str(row["group_id"]))
            running += int(row["size"])
    selected_set = set(selected)
    selected_size = development["group_id"].isin(selected_set).sum()
    if selected_size < target:
        remaining = group_rows.loc[~group_rows["group_id"].isin(selected_set)].copy()
        remaining = remaining.iloc[rng.permutation(len(remaining))]
        for row in remaining.itertuples(index=False):
            selected_set.add(str(row.group_id))
            selected_size += int(row.size)
            if selected_size >= target:
                break
    return selected_set


def build_nested_splits(table: pd.DataFrame, output_dir: Path, seed: int = 2026) -> list[Path]:
    if "duplicate_audit_complete" in table:
        audit_values = table["duplicate_audit_complete"]
        if audit_values.dtype == bool:
            complete = audit_values
        else:
            complete = audit_values.astype(str).str.casefold().eq("true")
        if not complete.all():
            raise ValueError("Duplicate audit contains pending candidate decisions")
    if table["group_id"].isna().any() or (table["group_id"].astype(str).str.len() == 0).any():
        raise ValueError("Every sample must have a reviewed connected group_id")
    splitter = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=seed)
    labels = stratification_labels(table)
    groups = table["group_id"].to_numpy()
    output_dir.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    for fold, (development_index, test_index) in enumerate(
        splitter.split(np.zeros(len(table)), labels, groups), start=1
    ):
        development = table.iloc[development_index]
        test_ids = set(table.iloc[test_index]["sample_id"].astype(str))
        validation_groups = _split_inner(development, seed + fold)
        roles = []
        for row in table.itertuples(index=False):
            if str(row.sample_id) in test_ids:
                role = "test"
            elif str(row.group_id) in validation_groups:
                role = "validation"
            else:
                role = "train"
            roles.append(role)
        split = pd.DataFrame(
            {
                "sample_id": table["sample_id"].astype(str),
                "group_id": table["group_id"].astype(str),
                "outer_fold": fold,
                "role": roles,
            }
        )
        assert_group_disjoint(split)
        target = output_dir / f"outer_fold_{fold}.csv"
        split.to_csv(target, index=False)
        paths.append(target)
    return paths


def assert_group_disjoint(split: pd.DataFrame) -> None:
    role_groups = {
        role: set(split.loc[split["role"] == role, "group_id"].astype(str))
        for role in ("train", "validation", "test")
    }
    if role_groups["train"] & role_groups["validation"]:
        raise AssertionError("Train and validation groups overlap")
    if role_groups["train"] & role_groups["test"]:
        raise AssertionError("Train and test groups overlap")
    if role_groups["validation"] & role_groups["test"]:
        raise AssertionError("Validation and test groups overlap")
