from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader


@torch.inference_mode()
def predict_loader(
    model: torch.nn.Module,
    loader: DataLoader,
    device: torch.device,
    amp: bool = True,
) -> pd.DataFrame:
    model.eval()
    rows: list[dict[str, object]] = []
    amp_enabled = amp and device.type == "cuda"
    for batch in loader:
        images = batch["image"].to(device, non_blocking=True)
        with torch.autocast(device_type=device.type, enabled=amp_enabled):
            outputs = model(images)
        mean = outputs["mean"].float().cpu().numpy()
        batch_size = len(mean)
        logvar_tensor = outputs.get("logvar", torch.zeros(batch_size, device=images.device))
        attribute_tensor = outputs.get(
            "attributes", torch.zeros(batch_size, 10, device=images.device)
        )
        reliability_tensor = outputs.get(
            "reliability", torch.ones(batch_size, 9, device=images.device)
        )
        aggregation_tensor = outputs.get(
            "aggregation", torch.full((batch_size, 9), 1.0 / 9.0, device=images.device)
        )
        logvar = logvar_tensor.float().cpu().numpy()
        attributes = attribute_tensor.float().cpu().numpy()
        reliability = reliability_tensor.float().cpu().numpy()
        aggregation = aggregation_tensor.float().cpu().numpy()
        true_attributes = batch["attributes"].numpy()
        masks = batch["attribute_mask"].numpy()
        for index, sample_id in enumerate(batch["sample_id"]):
            row: dict[str, object] = {
                "sample_id": sample_id,
                "group_id": batch["group_id"][index],
                "y_true": float(batch["target"][index]),
                "y_pred": float(mean[index]),
                "logvar": float(logvar[index]),
                "reliability_mean": float(np.mean(reliability[index])),
            }
            for attribute_index in range(10):
                row[f"attr_true_{attribute_index}"] = float(true_attributes[index, attribute_index])
                row[f"attr_pred_{attribute_index}"] = float(attributes[index, attribute_index])
                row[f"attr_mask_{attribute_index}"] = int(masks[index, attribute_index])
            for reliability_index, value in enumerate(reliability[index]):
                row[f"reliability_{reliability_index}"] = float(value)
            for weight_index, value in enumerate(aggregation[index]):
                row[f"aggregation_{weight_index}"] = float(value)
            rows.append(row)
    return pd.DataFrame(rows)


def save_predictions(table: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    table.sort_values("sample_id").to_csv(path, index=False)
