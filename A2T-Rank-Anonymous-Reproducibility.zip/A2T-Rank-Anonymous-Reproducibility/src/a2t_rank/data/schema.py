from __future__ import annotations

from dataclasses import dataclass

ATTRIBUTE_COLUMNS = (
    "attr_theme_logic",
    "attr_creativity",
    "attr_layout_composition",
    "attr_space_perspective",
    "attr_sense_order",
    "attr_light_shadow",
    "attr_color",
    "attr_details_texture",
    "attr_mood",
    "attr_overall",
)

MASK_COLUMNS = tuple(column.replace("attr_", "mask_") for column in ATTRIBUTE_COLUMNS)

OFFICIAL_COLUMN_MAP = {
    "filename": "relative_path",
    "Artistic Categories": "category",
    "Total aesthetic score": "total_score_source",
    "Theme and logic": "attr_theme_logic",
    "Creativity": "attr_creativity",
    "Layout and composition": "attr_layout_composition",
    "Space and perspective": "attr_space_perspective",
    "The sense of order": "attr_sense_order",
    "Light and shadow": "attr_light_shadow",
    "Color": "attr_color",
    "Details and texture": "attr_details_texture",
    "Mood": "attr_mood",
    "The overall": "attr_overall",
}

REQUIRED_MODEL_COLUMNS = (
    "sample_id",
    "relative_path",
    "total_score",
    "category",
    "group_id",
    *ATTRIBUTE_COLUMNS,
    *MASK_COLUMNS,
)


@dataclass(frozen=True)
class SplitAssignment:
    sample_id: str
    group_id: str
    outer_fold: int
    role: str
