from __future__ import annotations

import numpy as np

from a2t_rank.calibration import apply_affine_calibration, fit_affine_calibration


def test_affine_calibration_recovers_scale() -> None:
    mean = np.linspace(1.0, 9.0, 80)
    target = 1.15 * mean - 0.3
    logvar = np.full_like(mean, -1.0)
    calibration = fit_affine_calibration(target, mean, logvar, maximum_iterations=100)
    calibrated_mean, calibrated_logvar = apply_affine_calibration(mean, logvar, calibration)
    assert np.mean(np.abs(target - calibrated_mean)) < 1e-5
    assert np.isfinite(calibrated_logvar).all()
