# Data Interface

Third-party data are intentionally excluded. `a2t-prepare-data` converts the official APDDv2 annotation table into the canonical manifest used throughout the package.

Canonical columns are:

`sample_id`, `relative_path`, `total_score`, `category`, `attr_theme_logic`, `attr_creativity`, `attr_layout_composition`, `attr_space_perspective`, `attr_sense_order`, `attr_light_shadow`, `attr_color`, `attr_details_texture`, `attr_mood`, `attr_overall`, `mask_theme_logic`, `mask_creativity`, `mask_layout_composition`, `mask_space_perspective`, `mask_sense_order`, `mask_light_shadow`, `mask_color`, `mask_details_texture`, `mask_mood`, `mask_overall`, `sha256`, `phash`, `decode_ok`, `source_url`, `artist`, `title`, `group_id`, `duplicate_audit_complete`.

`total_score` is the official 0-100 value divided by 10. Attribute values remain on the official 0-10 scale. Missing attributes are represented by an empty numeric field and mask value 0.

The official annotation table does not contain complete artist and source metadata. Do not infer group independence from filenames alone. Add verified metadata and complete duplicate adjudication before building the locked splits.

