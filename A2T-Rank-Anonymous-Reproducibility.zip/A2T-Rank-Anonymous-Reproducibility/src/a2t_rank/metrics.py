from __future__ import annotations

from collections.abc import Callable

import numpy as np
import pandas as pd
from scipy import stats


def _finite_pair(target: np.ndarray, prediction: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    target = np.asarray(target, dtype=float)
    prediction = np.asarray(prediction, dtype=float)
    keep = np.isfinite(target) & np.isfinite(prediction)
    if keep.sum() < 2:
        raise ValueError("At least two finite target-prediction pairs are required")
    return target[keep], prediction[keep]


def regression_metrics(target: np.ndarray, prediction: np.ndarray) -> dict[str, float]:
    target, prediction = _finite_pair(target, prediction)
    residual = target - prediction
    return {
        "n": len(target),
        "srocc": float(stats.spearmanr(target, prediction).statistic),
        "plcc": float(stats.pearsonr(target, prediction).statistic),
        "mae": float(np.mean(np.abs(residual))),
        "mse": float(np.mean(residual**2)),
        "rmse": float(np.sqrt(np.mean(residual**2))),
    }


def gaussian_calibration_metrics(
    target: np.ndarray,
    mean: np.ndarray,
    logvar: np.ndarray,
    bins: int = 15,
) -> dict[str, float]:
    target = np.asarray(target, dtype=float)
    mean = np.asarray(mean, dtype=float)
    logvar = np.asarray(logvar, dtype=float)
    if not (len(target) == len(mean) == len(logvar)):
        raise ValueError("logvar length must match target length")
    keep = np.isfinite(target) & np.isfinite(mean) & np.isfinite(logvar)
    target, mean, logvar = target[keep], mean[keep], logvar[keep]
    if len(target) < 2:
        raise ValueError("At least two finite calibration rows are required")
    variance = np.exp(np.clip(logvar, -20, 20))
    standard_deviation = np.sqrt(variance)
    residual = target - mean
    nll = 0.5 * np.mean(logvar + residual**2 / variance)
    lower = mean - 1.959963984540054 * standard_deviation
    upper = mean + 1.959963984540054 * standard_deviation
    picp = np.mean((target >= lower) & (target <= upper))
    mpiw = np.mean(upper - lower)

    order = np.argsort(standard_deviation)
    chunks = np.array_split(order, bins)
    ence_parts = []
    for chunk in chunks:
        if len(chunk) == 0:
            continue
        rmse = np.sqrt(np.mean(residual[chunk] ** 2))
        rms_uncertainty = np.sqrt(np.mean(variance[chunk]))
        ence_parts.append(abs(rmse - rms_uncertainty) / max(rms_uncertainty, 1e-12))
    slope, intercept = np.polyfit(mean, target, deg=1)
    return {
        "nll": float(nll),
        "ence": float(np.mean(ence_parts)),
        "picp_95": float(picp),
        "mpiw_95": float(mpiw),
        "slope": float(slope),
        "intercept": float(intercept),
    }


def attribute_metrics(
    table: pd.DataFrame, names: list[str]
) -> tuple[pd.DataFrame, dict[str, float]]:
    rows = []
    for index, name in enumerate(names):
        target_column = f"attr_true_{index}"
        prediction_column = f"attr_pred_{index}"
        mask_column = f"attr_mask_{index}"
        active = table[mask_column].astype(bool)
        values = regression_metrics(
            table.loc[active, target_column].to_numpy(),
            table.loc[active, prediction_column].to_numpy(),
        )
        rows.append({"attribute": name, **values})
    result = pd.DataFrame(rows)
    macro = {
        "macro_srocc": float(result["srocc"].mean()),
        "macro_plcc": float(result["plcc"].mean()),
        "macro_mae": float(result["mae"].mean()),
    }
    return result, macro


def cluster_bootstrap(
    table: pd.DataFrame,
    metric: Callable[[pd.DataFrame], float],
    group_column: str = "group_id",
    draws: int = 10_000,
    seed: int = 2026,
) -> tuple[float, float, float]:
    groups = table[group_column].astype(str).unique()
    grouped = {group: table.loc[table[group_column].astype(str) == group] for group in groups}
    rng = np.random.default_rng(seed)
    values = np.empty(draws, dtype=float)
    for index in range(draws):
        chosen = rng.choice(groups, size=len(groups), replace=True)
        resampled = pd.concat([grouped[group] for group in chosen], ignore_index=True)
        values[index] = metric(resampled)
    point = metric(table)
    lower, upper = np.quantile(values, [0.025, 0.975])
    return float(point), float(lower), float(upper)


def reliability_diagnostics(table: pd.DataFrame) -> dict[str, object]:
    reliability = table["reliability_mean"].to_numpy(float)
    error = np.abs(table["y_true"].to_numpy(float) - table["y_pred"].to_numpy(float))
    correlation = stats.pearsonr(reliability, -error).statistic
    quantile = pd.qcut(reliability, 5, labels=False, duplicates="drop")
    quintile_mae = [float(error[quantile == index].mean()) for index in sorted(np.unique(quantile))]
    return {
        "correlation_with_negative_absolute_error": float(correlation),
        "quintile_mae": quintile_mae,
    }


def vab_set_metrics(table: pd.DataFrame) -> dict[str, float]:
    required = {"task_id", "candidate_id", "score", "is_best", "is_worst"}
    missing = required - set(table.columns)
    if missing:
        raise ValueError(f"VAB table is missing columns: {sorted(missing)}")
    best_correct: list[bool] = []
    worst_correct: list[bool] = []
    for _, task in table.groupby("task_id", sort=True):
        ranked = task.sort_values(["score", "candidate_id"], ascending=[False, True])
        predicted_best = ranked.iloc[0]["candidate_id"]
        predicted_worst = ranked.iloc[-1]["candidate_id"]
        true_best = set(task.loc[task["is_best"].astype(bool), "candidate_id"])
        true_worst = set(task.loc[task["is_worst"].astype(bool), "candidate_id"])
        best_correct.append(predicted_best in true_best)
        worst_correct.append(predicted_worst in true_worst)
    best = np.asarray(best_correct, dtype=bool)
    worst = np.asarray(worst_correct, dtype=bool)
    return {
        "tasks": len(best),
        "pick_best": float(best.mean()),
        "pick_worst": float(worst.mean()),
        "joint_best_worst": float((best & worst).mean()),
    }
