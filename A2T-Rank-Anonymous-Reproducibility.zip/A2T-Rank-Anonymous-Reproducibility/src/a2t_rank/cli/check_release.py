from __future__ import annotations

import argparse
from pathlib import Path

from a2t_rank.release import validate_release


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate repository release boundaries")
    parser.add_argument("--root", type=Path, default=Path("."))
    parser.add_argument("--strict", action="store_true")
    arguments = parser.parse_args()
    errors = validate_release(arguments.root.resolve(), arguments.strict)
    if errors:
        for error in errors:
            print(error)
        raise SystemExit(f"Release validation failed with {len(errors)} finding(s)")
    print("Release validation passed")


if __name__ == "__main__":
    main()
