from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from PIL import Image
from torch.utils.data import Dataset

from a2t_rank.data.schema import ATTRIBUTE_COLUMNS, MASK_COLUMNS, REQUIRED_MODEL_COLUMNS
from a2t_rank.data.transforms import ArtworkTransform, apply_corruption


def load_partition(manifest_path: Path, split_path: Path, role: str) -> pd.DataFrame:
    manifest = pd.read_csv(manifest_path)
    split = pd.read_csv(split_path, dtype={"sample_id": str, "group_id": str})
    missing = sorted(set(REQUIRED_MODEL_COLUMNS) - set(manifest.columns))
    if missing:
        raise ValueError(f"Manifest is missing required columns: {missing}")
    chosen = split.loc[split["role"] == role, ["sample_id", "group_id"]]
    table = manifest.merge(chosen, on=["sample_id", "group_id"], how="inner", validate="one_to_one")
    if len(table) != len(chosen):
        raise ValueError(f"Manifest and split mismatch for role {role}")
    return table


def category_mapping(manifest: pd.DataFrame) -> dict[str, int]:
    categories = sorted(manifest["category"].astype(str).unique())
    if len(categories) != 24:
        raise ValueError(f"Expected 24 categories, found {len(categories)}")
    return {name: index for index, name in enumerate(categories)}


class APDDv2Dataset(Dataset[dict[str, Any]]):
    def __init__(
        self,
        table: pd.DataFrame,
        image_root: Path,
        categories: dict[str, int],
        training: bool,
        image_size: int = 336,
        corruption: dict[str, Any] | None = None,
    ) -> None:
        self.table = table.reset_index(drop=True)
        self.image_root = image_root
        self.categories = categories
        self.transform = ArtworkTransform(image_size, training=training)
        self.corruption = corruption

    def __len__(self) -> int:
        return len(self.table)

    def __getitem__(self, index: int) -> dict[str, Any]:
        row = self.table.iloc[index]
        path = self.image_root / str(row["relative_path"])
        with Image.open(path) as image:
            if self.corruption:
                parameters = dict(self.corruption)
                kind = str(parameters.pop("kind"))
                image = apply_corruption(image.convert("RGB"), kind, **parameters)
            pixels = self.transform(image)
        attributes = row[list(ATTRIBUTE_COLUMNS)].to_numpy(dtype=np.float32, na_value=np.nan)
        masks = row[list(MASK_COLUMNS)].to_numpy(dtype=np.float32)
        attributes = np.nan_to_num(attributes, nan=0.0)
        return {
            "image": pixels,
            "target": torch.tensor(float(row["total_score"]), dtype=torch.float32),
            "attributes": torch.from_numpy(attributes),
            "attribute_mask": torch.from_numpy(masks),
            "category": torch.tensor(self.categories[str(row["category"])], dtype=torch.long),
            "sample_id": str(row["sample_id"]),
            "group_id": str(row["group_id"]),
        }


class ExternalImageDataset(Dataset[dict[str, Any]]):
    def __init__(self, table: pd.DataFrame, image_root: Path, image_size: int = 336) -> None:
        required = {"sample_id", "relative_path"}
        missing = required - set(table.columns)
        if missing:
            raise ValueError(f"External manifest is missing columns: {sorted(missing)}")
        self.table = table.reset_index(drop=True)
        self.image_root = image_root
        self.transform = ArtworkTransform(image_size, training=False)

    def __len__(self) -> int:
        return len(self.table)

    def __getitem__(self, index: int) -> dict[str, Any]:
        row = self.table.iloc[index]
        with Image.open(self.image_root / str(row["relative_path"])) as image:
            pixels = self.transform(image)
        target = (
            float(row["total_score"])
            if "total_score" in row and pd.notna(row["total_score"])
            else float("nan")
        )
        return {
            "image": pixels,
            "target": torch.tensor(target, dtype=torch.float32),
            "attributes": torch.zeros(10, dtype=torch.float32),
            "attribute_mask": torch.zeros(10, dtype=torch.float32),
            "category": torch.tensor(0, dtype=torch.long),
            "sample_id": str(row["sample_id"]),
            "group_id": str(row.get("group_id", row["sample_id"])),
        }
