from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml


def load_yaml(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle)
    return value or {}


def set_dotted(config: dict[str, Any], dotted_key: str, value: Any) -> None:
    cursor = config
    parts = dotted_key.split(".")
    for part in parts[:-1]:
        cursor = cursor.setdefault(part, {})
    cursor[parts[-1]] = value


def apply_flat_overrides(config: dict[str, Any], overrides: dict[str, Any]) -> dict[str, Any]:
    updated = deepcopy(config)
    for key, value in overrides.items():
        set_dotted(updated, key, value)
    return updated


def parse_cli_overrides(items: list[str]) -> dict[str, Any]:
    parsed: dict[str, Any] = {}
    for item in items:
        if "=" not in item:
            raise ValueError(f"Override must use key=value syntax: {item}")
        key, raw = item.split("=", 1)
        parsed[key] = yaml.safe_load(raw)
    return parsed
