from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats


def spearman_difference(table: pd.DataFrame, left: str, right: str) -> float:
    target = table["y_true"].to_numpy(float)
    left_value = stats.spearmanr(target, table[left].to_numpy(float)).statistic
    right_value = stats.spearmanr(target, table[right].to_numpy(float)).statistic
    return float(left_value - right_value)


def paired_cluster_bootstrap_difference(
    table: pd.DataFrame,
    left: str,
    right: str,
    draws: int = 10_000,
    seed: int = 2026,
) -> tuple[float, float, float]:
    groups = table["group_id"].astype(str).unique()
    grouped = {group: table.loc[table["group_id"].astype(str) == group] for group in groups}
    rng = np.random.default_rng(seed)
    differences = np.empty(draws, dtype=float)
    for index in range(draws):
        chosen = rng.choice(groups, size=len(groups), replace=True)
        sampled = pd.concat([grouped[group] for group in chosen], ignore_index=True)
        differences[index] = spearman_difference(sampled, left, right)
    lower, upper = np.quantile(differences, [0.025, 0.975])
    return spearman_difference(table, left, right), float(lower), float(upper)


def paired_permutation_test(
    table: pd.DataFrame,
    left: str,
    right: str,
    draws: int = 10_000,
    seed: int = 2026,
) -> float:
    observed = abs(spearman_difference(table, left, right))
    rng = np.random.default_rng(seed)
    left_values = table[left].to_numpy(float)
    right_values = table[right].to_numpy(float)
    target = table["y_true"].to_numpy(float)
    exceed = 0
    for _ in range(draws):
        swap = rng.random(len(table)) < 0.5
        permuted_left = np.where(swap, right_values, left_values)
        permuted_right = np.where(swap, left_values, right_values)
        difference = abs(
            stats.spearmanr(target, permuted_left).statistic
            - stats.spearmanr(target, permuted_right).statistic
        )
        exceed += difference >= observed
    return float((exceed + 1) / (draws + 1))


def holm_adjust(p_values: list[float]) -> list[float]:
    count = len(p_values)
    order = np.argsort(p_values)
    adjusted = np.empty(count, dtype=float)
    running = 0.0
    for rank, index in enumerate(order):
        value = min(1.0, (count - rank) * p_values[index])
        running = max(running, value)
        adjusted[index] = running
    return adjusted.tolist()
