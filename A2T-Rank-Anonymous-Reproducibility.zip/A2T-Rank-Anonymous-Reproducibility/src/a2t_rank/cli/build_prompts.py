from __future__ import annotations

import argparse
from pathlib import Path

from a2t_rank.prompt_bank import build_prompt_bank


def main() -> None:
    parser = argparse.ArgumentParser(description="Build and hash the immutable prompt bank")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--checkpoint", default="openai/clip-vit-large-patch14-336")
    parser.add_argument("--revision", default="main")
    parser.add_argument("--projection-seed", type=int, default=2026)
    arguments = parser.parse_args()
    record = build_prompt_bank(
        arguments.output,
        arguments.metadata,
        arguments.checkpoint,
        arguments.revision,
        arguments.projection_seed,
    )
    print(record["artifact_sha256"])


if __name__ == "__main__":
    main()
