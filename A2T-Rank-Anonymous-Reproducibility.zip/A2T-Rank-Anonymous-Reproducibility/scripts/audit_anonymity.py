from __future__ import annotations

import argparse
import re
from pathlib import Path

TEXT_SUFFIXES = {
    ".py",
    ".md",
    ".yaml",
    ".yml",
    ".toml",
    ".json",
    ".jsonl",
    ".csv",
    ".txt",
    ".cff",
    ".sh",
}
PATTERNS = {
    "email": re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE),
    "orcid": re.compile(r"\b\d{4}-\d{4}-\d{4}-[\dX]{4}\b"),
    "absolute_home_path": re.compile(
        r"(?:"
        + re.escape("/" + "home" + "/")
        + "|"
        + re.escape("/" + "Users" + "/")
        + r"|[A-Z]:\\"
        + "Users"
        + r"\\)[^\s'\"]+",
        re.IGNORECASE,
    ),
    "credential_assignment": re.compile(
        r"(?:api[_-]?key|token|secret|password)\s*[:=]\s*[^\s]+", re.IGNORECASE
    ),
}


def main() -> None:
    parser = argparse.ArgumentParser(description="Flag identity and credential traces")
    parser.add_argument("root", nargs="?", type=Path, default=Path("."))
    arguments = parser.parse_args()
    findings = []
    for path in arguments.root.rglob("*"):
        if not path.is_file() or path.suffix.casefold() not in TEXT_SUFFIXES:
            continue
        if any(part in {".git", ".venv", "__pycache__"} for part in path.parts):
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for name, pattern in PATTERNS.items():
            for match in pattern.finditer(text):
                findings.append(f"{path}:{name}:{match.group(0)[:80]}")
    if findings:
        print("\n".join(findings))
        raise SystemExit(1)
    print("Automated anonymity audit passed")


if __name__ == "__main__":
    main()
