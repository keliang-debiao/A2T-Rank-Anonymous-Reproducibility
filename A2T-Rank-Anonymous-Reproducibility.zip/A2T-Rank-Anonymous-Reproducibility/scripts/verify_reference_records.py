from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


def main() -> None:
    root = Path("reference_records")
    status = json.loads((root / "STATUS.json").read_text(encoding="utf-8"))
    required_status = "reference_values_pending_empirical_reproduction"
    if status["artifact_status"] != required_status:
        raise SystemExit("Reference status mismatch")
    for path in root.glob("*.csv"):
        table = pd.read_csv(path)
        if "record_status" not in table or set(table["record_status"]) != {required_status}:
            raise SystemExit(f"Reference status missing or inconsistent in {path}")
    lines = (root / "training_target_records.jsonl").read_text(encoding="utf-8").splitlines()
    records = [json.loads(line) for line in lines if line.strip()]
    if len(records) != 25:
        raise SystemExit(f"Expected 25 seed-fold reference records, found {len(records)}")
    if any(record.get("record_status") != required_status for record in records):
        raise SystemExit("A training target record has an invalid status")
    print("Reference record verification passed")


if __name__ == "__main__":
    main()
