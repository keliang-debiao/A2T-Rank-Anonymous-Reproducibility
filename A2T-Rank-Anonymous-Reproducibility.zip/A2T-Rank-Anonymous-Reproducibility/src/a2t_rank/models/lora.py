from __future__ import annotations

import math

import torch
from torch import nn


class LoRALinear(nn.Module):
    def __init__(self, base: nn.Linear, rank: int, alpha: int, dropout: float) -> None:
        super().__init__()
        self.base = base
        for parameter in self.base.parameters():
            parameter.requires_grad = False
        self.rank = rank
        self.scaling = alpha / rank
        self.dropout = nn.Dropout(dropout)
        self.lora_a = nn.Linear(base.in_features, rank, bias=False)
        self.lora_b = nn.Linear(rank, base.out_features, bias=False)
        nn.init.kaiming_uniform_(self.lora_a.weight, a=math.sqrt(5))
        nn.init.zeros_(self.lora_b.weight)

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return self.base(inputs) + self.lora_b(self.lora_a(self.dropout(inputs))) * self.scaling


def inject_clip_lora(
    clip_vision: nn.Module,
    rank: int,
    alpha: int,
    dropout: float,
    top_blocks: int,
) -> None:
    layers = clip_vision.vision_model.encoder.layers
    start = max(0, len(layers) - top_blocks)
    for layer in layers[start:]:
        attention = layer.self_attn
        attention.q_proj = LoRALinear(attention.q_proj, rank, alpha, dropout)
        attention.v_proj = LoRALinear(attention.v_proj, rank, alpha, dropout)
