from __future__ import annotations

import argparse
from pathlib import Path

from a2t_rank.config import apply_flat_overrides, load_yaml, parse_cli_overrides
from a2t_rank.training import train_seed_fold


def main() -> None:
    parser = argparse.ArgumentParser(description="Train one locked A2T-Rank seed-fold job")
    parser.add_argument("--config", type=Path, default=Path("configs/a2t_rank.yaml"))
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--fold", type=int, choices=range(1, 6), required=True)
    parser.add_argument("--ablation")
    parser.add_argument("--ablation-config", type=Path, default=Path("configs/ablations.yaml"))
    parser.add_argument("--set", action="append", default=[])
    arguments = parser.parse_args()
    config = load_yaml(arguments.config)
    if arguments.ablation:
        variants = load_yaml(arguments.ablation_config)
        if arguments.ablation not in variants:
            raise SystemExit(f"Unknown ablation: {arguments.ablation}")
        config = apply_flat_overrides(config, variants[arguments.ablation])
    config = apply_flat_overrides(config, parse_cli_overrides(arguments.set))
    allowed_seeds = set(config["experiment"]["seeds"])
    if arguments.seed not in allowed_seeds:
        raise SystemExit(f"Seed {arguments.seed} is outside the locked protocol")
    summary = train_seed_fold(config, arguments.seed, arguments.fold)
    print(summary)


if __name__ == "__main__":
    main()
