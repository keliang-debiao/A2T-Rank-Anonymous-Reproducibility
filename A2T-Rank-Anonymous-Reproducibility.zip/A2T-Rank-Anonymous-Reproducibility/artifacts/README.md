# Runtime Artifact Layout

Executed jobs write only to this directory. The committed repository keeps directory documentation but excludes checkpoints, per-image predictions, and machine logs until the full dataset protocol has been run.

Required subdirectories are `checkpoints`, `predictions`, `runtime_logs`, `calibration`, `metrics`, `statistics`, and `audit`.

