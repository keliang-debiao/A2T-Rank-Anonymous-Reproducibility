from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

from a2t_rank.config import load_yaml
from a2t_rank.data.dataset import ExternalImageDataset
from a2t_rank.models import A2TRank
from a2t_rank.prediction import predict_loader, save_predictions
from a2t_rank.utils import sha256_file, write_json


def _prompt_tensor(path: Path) -> torch.Tensor:
    payload = torch.load(path, map_location="cpu", weights_only=True)
    return payload["queries"] if isinstance(payload, dict) else payload


def main() -> None:
    parser = argparse.ArgumentParser(description="Run frozen image-only checkpoint inference")
    parser.add_argument("--config", type=Path, default=Path("configs/a2t_rank.yaml"))
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, action="append", required=True)
    parser.add_argument("--prompt-bank", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--num-workers", type=int, default=8)
    arguments = parser.parse_args()

    config = load_yaml(arguments.config)
    table = pd.read_csv(arguments.manifest, dtype={"sample_id": str})
    dataset = ExternalImageDataset(
        table, arguments.image_root, int(config["experiment"]["image_size"])
    )
    loader = DataLoader(
        dataset,
        batch_size=arguments.batch_size,
        shuffle=False,
        num_workers=arguments.num_workers,
        pin_memory=True,
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    prompt_bank = _prompt_tensor(arguments.prompt_bank)
    prediction_tables: list[pd.DataFrame] = []
    checkpoint_hashes = []
    for checkpoint_path in arguments.checkpoint:
        model = A2TRank(config, prompt_bank).to(device)
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
        state = checkpoint.get("model_state", checkpoint)
        model.load_state_dict(state)
        prediction_tables.append(
            predict_loader(model, loader, device, bool(config["train"]["amp"]))
        )
        checkpoint_hashes.append(sha256_file(checkpoint_path))
        del model
        if device.type == "cuda":
            torch.cuda.empty_cache()

    base = prediction_tables[0].copy()
    numeric_columns = [
        column
        for column in base.columns
        if column.startswith(("y_pred", "attr_pred_", "reliability_", "aggregation_"))
        or column == "reliability_mean"
    ]
    for column in numeric_columns:
        base[column] = np.mean(
            [frame[column].to_numpy(float) for frame in prediction_tables], axis=0
        )
    means = np.stack([frame["y_pred"].to_numpy(float) for frame in prediction_tables])
    variances = np.stack([np.exp(frame["logvar"].to_numpy(float)) for frame in prediction_tables])
    ensemble_variance = np.mean(variances + means**2, axis=0) - np.mean(means, axis=0) ** 2
    base["logvar"] = np.log(np.clip(ensemble_variance, 1e-8, None))
    base["model_count"] = len(prediction_tables)
    save_predictions(base, arguments.output)
    write_json(
        arguments.output.with_suffix(".manifest.json"),
        {
            "status": "executed",
            "checkpoint_count": len(checkpoint_hashes),
            "checkpoint_sha256": checkpoint_hashes,
            "external_calibration": False,
            "prediction_rows": len(base),
        },
    )
    print(f"Wrote {len(base)} predictions from {len(checkpoint_hashes)} checkpoints")


if __name__ == "__main__":
    main()
