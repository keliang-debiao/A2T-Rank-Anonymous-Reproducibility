from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from a2t_rank.statistics import (
    holm_adjust,
    paired_cluster_bootstrap_difference,
    paired_permutation_test,
)
from a2t_rank.utils import write_json


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run paired grouped inference on frozen OOF predictions"
    )
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--left", required=True)
    parser.add_argument("--right", action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=2026)
    arguments = parser.parse_args()
    table = pd.read_csv(arguments.predictions, dtype={"group_id": str})
    rows = []
    p_values = []
    for index, right in enumerate(arguments.right):
        difference, lower, upper = paired_cluster_bootstrap_difference(
            table, arguments.left, right, arguments.draws, arguments.seed + index
        )
        p_value = paired_permutation_test(
            table, arguments.left, right, arguments.draws, arguments.seed + index
        )
        p_values.append(p_value)
        rows.append(
            {
                "left": arguments.left,
                "right": right,
                "difference": difference,
                "ci_95": [lower, upper],
                "permutation_p": p_value,
            }
        )
    for row, adjusted in zip(rows, holm_adjust(p_values), strict=True):
        row["holm_adjusted_p"] = adjusted
    write_json(arguments.output, {"contrasts": rows})
    print(rows)


if __name__ == "__main__":
    main()
