from __future__ import annotations

import re
from collections import defaultdict
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd


def normalize_text(value: object) -> str:
    text = "" if pd.isna(value) else str(value).casefold().strip()
    return re.sub(r"[^\w]+", " ", text).strip()


def hamming_hex(left: str, right: str) -> int:
    return (int(left, 16) ^ int(right, 16)).bit_count()


class UnionFind:
    def __init__(self, values: Iterable[str]) -> None:
        self.parent = {value: value for value in values}
        self.rank = {value: 0 for value in values}

    def find(self, value: str) -> str:
        root = value
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[value] != value:
            parent = self.parent[value]
            self.parent[value] = root
            value = parent
        return root

    def union(self, left: str, right: str) -> None:
        root_left, root_right = self.find(left), self.find(right)
        if root_left == root_right:
            return
        if self.rank[root_left] < self.rank[root_right]:
            root_left, root_right = root_right, root_left
        self.parent[root_right] = root_left
        if self.rank[root_left] == self.rank[root_right]:
            self.rank[root_left] += 1


@dataclass(frozen=True)
class CandidatePair:
    left_id: str
    right_id: str
    basis: str
    value: float | str
    auto_accept: bool


def exact_candidates(table: pd.DataFrame) -> list[CandidatePair]:
    pairs: list[CandidatePair] = []
    hashes = table["sha256"].fillna("").astype(str).str.casefold()
    valid = hashes.str.fullmatch(r"[0-9a-f]{64}")
    filtered = table.loc[valid].copy()
    filtered["sha256"] = hashes[valid]
    for _, group in filtered.groupby("sha256"):
        ids = sorted(group["sample_id"].astype(str))
        pairs.extend(
            CandidatePair(ids[0], value, "sha256", group.iloc[0]["sha256"], True)
            for value in ids[1:]
        )
    return pairs


def metadata_candidates(table: pd.DataFrame) -> list[CandidatePair]:
    pairs: list[CandidatePair] = []
    source_groups: dict[str, list[str]] = defaultdict(list)
    title_artist_groups: dict[str, list[str]] = defaultdict(list)
    for row in table.itertuples(index=False):
        sample_id = str(row.sample_id)
        source = normalize_text(getattr(row, "source_url", ""))
        artist = normalize_text(getattr(row, "artist", ""))
        title = normalize_text(getattr(row, "title", ""))
        if source:
            source_groups[source].append(sample_id)
        if artist and title:
            title_artist_groups[f"{artist}|{title}"].append(sample_id)
    for basis, groups in (("source_url", source_groups), ("title_artist", title_artist_groups)):
        for key, ids in groups.items():
            ids = sorted(set(ids))
            pairs.extend(CandidatePair(ids[0], value, basis, key, True) for value in ids[1:])
    return pairs


def phash_candidates(table: pd.DataFrame, threshold: int = 6) -> list[CandidatePair]:
    values = []
    for row in table.itertuples(index=False):
        value = "" if pd.isna(row.phash) else str(row.phash).strip().casefold()
        if re.fullmatch(r"[0-9a-f]{16}", value):
            values.append((str(row.sample_id), value))
    pairs: list[CandidatePair] = []
    root: tuple[str, str, dict[int, object]] | None = None

    def insert(node: tuple[str, str, dict[int, object]], sample_id: str, value: str) -> None:
        cursor = node
        while True:
            distance = hamming_hex(value, cursor[1])
            child = cursor[2].get(distance)
            if child is None:
                cursor[2][distance] = (sample_id, value, {})
                return
            cursor = child  # type: ignore[assignment]

    def search(node: tuple[str, str, dict[int, object]], value: str) -> list[tuple[str, str, int]]:
        matches: list[tuple[str, str, int]] = []
        stack = [node]
        while stack:
            cursor = stack.pop()
            distance = hamming_hex(value, cursor[1])
            if distance <= threshold:
                matches.append((cursor[0], cursor[1], distance))
            lower, upper = distance - threshold, distance + threshold
            stack.extend(
                child  # type: ignore[arg-type]
                for edge, child in cursor[2].items()
                if lower <= edge <= upper
            )
        return matches

    for sample_id, perceptual_hash in values:
        if root is None:
            root = (sample_id, perceptual_hash, {})
            continue
        for other_id, _, distance in search(root, perceptual_hash):
            pairs.append(CandidatePair(other_id, sample_id, "phash", float(distance), False))
        insert(root, sample_id, perceptual_hash)
    return pairs


def embedding_candidates(npz_path: Path, threshold: float = 0.985) -> list[CandidatePair]:
    data = np.load(npz_path, allow_pickle=False)
    ids = data["sample_id"].astype(str)
    embeddings = data["embedding"].astype(np.float32)
    embeddings /= np.linalg.norm(embeddings, axis=1, keepdims=True).clip(min=1e-12)
    pairs: list[CandidatePair] = []
    block = 1024
    for start in range(0, len(ids), block):
        scores = embeddings[start : start + block] @ embeddings.T
        for local, row_scores in enumerate(scores):
            left = start + local
            matches = np.where(row_scores >= threshold)[0]
            for right in matches:
                if right > left:
                    pairs.append(
                        CandidatePair(
                            ids[left], ids[right], "dinov2", float(row_scores[right]), False
                        )
                    )
    return pairs


def assign_groups(table: pd.DataFrame, accepted_pairs: list[CandidatePair]) -> pd.DataFrame:
    result = table.copy()
    union_find = UnionFind(result["sample_id"].astype(str))
    for pair in accepted_pairs:
        union_find.union(pair.left_id, pair.right_id)
    roots = result["sample_id"].astype(str).map(union_find.find)
    root_to_group = {root: f"g{index:06d}" for index, root in enumerate(sorted(set(roots)))}
    result["group_id"] = roots.map(root_to_group)
    return result


def candidate_table(pairs: list[CandidatePair]) -> pd.DataFrame:
    columns = ["left_id", "right_id", "basis", "value", "auto_accept", "review_status"]
    table = pd.DataFrame(
        [
            {
                "left_id": pair.left_id,
                "right_id": pair.right_id,
                "basis": pair.basis,
                "value": pair.value,
                "auto_accept": pair.auto_accept,
                "review_status": "accepted" if pair.auto_accept else "pending_manual_review",
            }
            for pair in pairs
        ],
        columns=columns,
    )
    if len(table):
        table["_pair_key"] = [
            "|".join(sorted((str(left), str(right))))
            for left, right in zip(table["left_id"], table["right_id"], strict=True)
        ]
        accepted_keys = set(table.loc[table["auto_accept"], "_pair_key"])
        table.loc[table["_pair_key"].isin(accepted_keys), "review_status"] = "accepted"
        table = table.drop(columns="_pair_key")
    return table
