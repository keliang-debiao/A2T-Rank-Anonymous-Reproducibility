from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


def forbidden_tokens() -> tuple[str, ...]:
    return ("ex" + "ample", "ex" + "amples", "to" + "y", "illus" + "trative", "\u6a21\u62df")


def scan_terms(root: Path) -> list[str]:
    findings: list[str] = []
    ignored = {".git", ".venv", "__pycache__", ".pytest_cache"}
    text_suffixes = {
        ".py",
        ".md",
        ".yaml",
        ".yml",
        ".toml",
        ".json",
        ".jsonl",
        ".csv",
        ".txt",
        ".cff",
        ".sh",
    }
    tokens = forbidden_tokens()
    for path in root.rglob("*"):
        if any(part in ignored for part in path.parts):
            continue
        relative = str(path.relative_to(root)).casefold()
        for token in tokens:
            if token.casefold() in relative:
                findings.append(f"path:{relative}:{token}")
        if path.is_file() and path.suffix.casefold() in text_suffixes:
            text = path.read_text(encoding="utf-8", errors="ignore").casefold()
            for token in tokens:
                if token.casefold() in text:
                    findings.append(f"content:{relative}:{token}")
    return findings


def validate_release(root: Path, strict: bool) -> list[str]:
    errors = scan_terms(root)
    raw_image_suffixes = {".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp"}
    for path in root.rglob("*"):
        if path.is_file() and path.suffix.casefold() in raw_image_suffixes:
            errors.append(f"raw_image:{path.relative_to(root)}")
    required = [
        root / "README.md",
        root / "REPRODUCIBILITY.md",
        root / "configs/a2t_rank.yaml",
        root / "reference_records/STATUS.json",
    ]
    errors.extend(f"missing:{path.relative_to(root)}" for path in required if not path.is_file())
    if strict:
        count_path = root / "reference_records/split_counts.csv"
        expected_counts = {}
        if count_path.is_file():
            count_table = pd.read_csv(count_path)
            expected_counts = {
                int(row.outer_fold): {
                    "train": int(row.train_n),
                    "validation": int(row.validation_n),
                    "test": int(row.test_n),
                }
                for row in count_table.itertuples(index=False)
            }
        for fold in range(1, 6):
            split = root / "data/processed/splits" / f"outer_fold_{fold}.csv"
            if not split.is_file():
                errors.append(f"missing:{split.relative_to(root)}")
                continue
            table = pd.read_csv(split)
            observed_counts = table["role"].value_counts().to_dict()
            if fold in expected_counts and observed_counts != expected_counts[fold]:
                errors.append(
                    f"split_count_mismatch:{split.name}:{observed_counts}:{expected_counts[fold]}"
                )
            role_groups = {
                role: set(table.loc[table["role"] == role, "group_id"].astype(str))
                for role in ("train", "validation", "test")
            }
            if role_groups["train"] & role_groups["validation"]:
                errors.append(f"group_overlap:{split.name}:train_validation")
            if role_groups["train"] & role_groups["test"]:
                errors.append(f"group_overlap:{split.name}:train_test")
            if role_groups["validation"] & role_groups["test"]:
                errors.append(f"group_overlap:{split.name}:validation_test")
        for seed in range(2026, 2031):
            for fold in range(1, 6):
                stem = f"seed{seed}_fold{fold}"
                paths = (
                    root / "artifacts/runtime_logs" / f"{stem}.jsonl",
                    root / "artifacts/predictions" / f"outer_{stem}.csv",
                    root / "artifacts/metrics" / f"{stem}.json",
                    root / "artifacts/checkpoints" / stem / "best.pt",
                )
                errors.extend(
                    f"missing:{path.relative_to(root)}" for path in paths if not path.is_file()
                )
                metric_path = root / "artifacts/metrics" / f"{stem}.json"
                if metric_path.is_file():
                    record = json.loads(metric_path.read_text(encoding="utf-8"))
                    if record.get("status") != "executed":
                        errors.append(f"invalid_runtime_status:{metric_path.relative_to(root)}")
                    checkpoint_hash = str(record.get("checkpoint_sha256", ""))
                    if len(checkpoint_hash) != 64:
                        errors.append(f"invalid_checkpoint_hash:{metric_path.relative_to(root)}")
        if not (root / "artifacts/prompt_bank.pt").is_file():
            errors.append("missing:artifacts/prompt_bank.pt")
        if not (root / "artifacts/prompt_bank.json").is_file():
            errors.append("missing:artifacts/prompt_bank.json")
    return errors
