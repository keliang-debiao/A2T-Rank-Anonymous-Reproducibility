from __future__ import annotations

from typing import Any

import torch
import torch.nn.functional as F


def masked_huber(
    prediction: torch.Tensor,
    target: torch.Tensor,
    mask: torch.Tensor,
    zero_fill_missing: bool,
) -> torch.Tensor:
    active = torch.ones_like(mask) if zero_fill_missing else mask
    element = F.huber_loss(prediction, target, reduction="none", delta=1.0)
    return (element * active).sum() / active.sum().clamp_min(1e-8)


def pairwise_ranking_loss(
    prediction: torch.Tensor,
    target: torch.Tensor,
    minimum_gap: float,
    maximum_pairs: int,
) -> torch.Tensor:
    left, right = torch.triu_indices(len(target), len(target), offset=1, device=target.device)
    gaps = target[left] - target[right]
    keep = gaps.abs() >= minimum_gap
    left, right, gaps = left[keep], right[keep], gaps[keep]
    if len(left) == 0:
        return prediction.new_zeros(())
    if len(left) > maximum_pairs:
        chosen = torch.randperm(len(left), device=target.device)[:maximum_pairs]
        left, right, gaps = left[chosen], right[chosen], gaps[chosen]
    signed_margin = gaps.sign() * (prediction[left] - prediction[right])
    return F.softplus(-signed_margin).mean()


def orthogonality_loss(left: torch.Tensor, right: torch.Tensor) -> torch.Tensor:
    cosine = F.cosine_similarity(left, right, dim=-1, eps=1e-6)
    return cosine.square().mean()


def prompt_alignment_loss(
    queries: torch.Tensor, prompts: torch.Tensor, temperature: float
) -> torch.Tensor:
    normalized_queries = F.normalize(queries, dim=-1)
    normalized_prompts = F.normalize(prompts, dim=-1)
    logits = torch.einsum("bkd,jd->bkj", normalized_queries, normalized_prompts) / temperature
    labels = (
        torch.arange(prompts.shape[0], device=queries.device)
        .view(1, -1)
        .expand(queries.shape[0], -1)
    )
    return F.cross_entropy(logits.flatten(0, 1), labels.flatten())


def reliability_loss(
    reliability: torch.Tensor,
    attribute_prediction: torch.Tensor,
    attribute_target: torch.Tensor,
    mask: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    count = min(9, reliability.shape[1])
    prediction = attribute_prediction[:, :count]
    target = attribute_target[:, :count]
    active = mask[:, :count]
    supervisory = torch.exp(-(target - prediction).abs() / temperature).detach()
    element = F.binary_cross_entropy(reliability[:, :count], supervisory, reduction="none")
    return (element * active).sum() / active.sum().clamp_min(1e-8)


def compute_losses(
    outputs: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    config: dict[str, Any],
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    settings = config["loss"]
    train = config["train"]
    model = config["model"]
    target = batch["target"]
    attribute_target = batch["attributes"]
    mask = batch["attribute_mask"]

    terms: dict[str, torch.Tensor] = {}
    terms["main"] = F.huber_loss(outputs["mean"], target, delta=1.0)
    terms["attribute"] = masked_huber(
        outputs["attributes"],
        attribute_target,
        mask,
        bool(model["zero_fill_missing"]),
    )
    terms["rank"] = pairwise_ranking_loss(
        outputs["mean"], target, float(train["pair_gap"]), int(train["max_rank_pairs"])
    )
    terms["prompt"] = prompt_alignment_loss(
        outputs["queries"],
        outputs["prompt_bank"],
        float(settings["prompt_temperature"]),
    )
    terms["reliability"] = reliability_loss(
        outputs["reliability"],
        outputs["attributes"],
        attribute_target,
        mask,
        float(settings["reliability_temperature"]),
    )
    terms["category"] = F.cross_entropy(outputs["category_specific"], batch["category"])
    terms["adversarial"] = F.cross_entropy(outputs["category_invariant"], batch["category"])
    terms["orthogonality"] = orthogonality_loss(
        outputs["style_specific"], outputs["style_invariant"]
    )
    residual_square = (target - outputs["mean"]).square()
    terms["uncertainty"] = (
        0.5 * (torch.exp(-outputs["logvar"]) * residual_square + outputs["logvar"]).mean()
    )

    if not bool(model["use_attribute_supervision"]):
        terms["attribute"] = terms["attribute"].detach() * 0.0
    if not bool(model["use_reliability"]):
        terms["reliability"] = terms["reliability"].detach() * 0.0
    if not bool(model["use_style_specific"]):
        terms["category"] = terms["category"].detach() * 0.0
    if not bool(model["use_style_invariant"]):
        terms["adversarial"] = terms["adversarial"].detach() * 0.0
    if not (bool(model["use_style_specific"]) and bool(model["use_style_invariant"])):
        terms["orthogonality"] = terms["orthogonality"].detach() * 0.0
    total = sum(float(settings[name]) * value for name, value in terms.items())
    return total, terms
