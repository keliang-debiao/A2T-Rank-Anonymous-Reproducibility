"""A2T-Rank reproducibility implementation."""

__version__ = "1.0.0"
