from __future__ import annotations

import io
import random

import torch
from PIL import Image, ImageOps
from torchvision.transforms import InterpolationMode
from torchvision.transforms import functional as TF


def resize_and_pad(image: Image.Image, size: int = 336) -> Image.Image:
    image = image.convert("RGB")
    width, height = image.size
    scale = min(size / max(width, 1), size / max(height, 1))
    new_width = max(1, round(width * scale))
    new_height = max(1, round(height * scale))
    resized = image.resize((new_width, new_height), Image.Resampling.BICUBIC)
    left = (size - new_width) // 2
    top = (size - new_height) // 2
    right = size - new_width - left
    bottom = size - new_height - top
    return ImageOps.expand(resized, (left, top, right, bottom), fill=(255, 255, 255))


def jpeg_reencode(image: Image.Image, quality: int) -> Image.Image:
    buffer = io.BytesIO()
    image.save(buffer, format="JPEG", quality=quality, optimize=False)
    buffer.seek(0)
    result = Image.open(buffer).convert("RGB")
    result.load()
    return result


class ArtworkTransform:
    def __init__(self, size: int = 336, training: bool = False) -> None:
        self.size = size
        self.training = training

    def __call__(self, image: Image.Image) -> torch.Tensor:
        image = resize_and_pad(image, self.size)
        if self.training:
            scale = random.uniform(0.95, 1.05)
            translate = (
                round(random.uniform(-0.02, 0.02) * self.size),
                round(random.uniform(-0.02, 0.02) * self.size),
            )
            image = TF.affine(
                image,
                angle=0.0,
                translate=translate,
                scale=scale,
                shear=[0.0, 0.0],
                interpolation=InterpolationMode.BICUBIC,
                fill=[255, 255, 255],
            )
            image = jpeg_reencode(image, random.randint(92, 100))
        return TF.pil_to_tensor(image).float().div_(255.0)


def apply_corruption(image: Image.Image, kind: str, **parameters: float) -> Image.Image:
    image = resize_and_pad(image, 336)
    if kind == "jpeg":
        return jpeg_reencode(image, int(parameters["quality"]))
    if kind == "gaussian_blur":
        sigma = float(parameters["sigma"])
        return TF.gaussian_blur(image, kernel_size=9, sigma=sigma)
    if kind == "downsample_restore":
        size = int(parameters["size"])
        return image.resize((size, size), Image.Resampling.BICUBIC).resize(
            (336, 336), Image.Resampling.BICUBIC
        )
    if kind == "brightness":
        return TF.adjust_brightness(image, float(parameters["factor"]))
    if kind == "contrast":
        return TF.adjust_contrast(image, float(parameters["factor"]))
    if kind == "central_occlusion":
        fraction = float(parameters["area_fraction"])
        side = round(336 * fraction**0.5)
        left = (336 - side) // 2
        top = (336 - side) // 2
        copy = image.copy()
        copy.paste((255, 255, 255), (left, top, left + side, top + side))
        return copy
    raise ValueError(f"Unknown corruption kind: {kind}")
