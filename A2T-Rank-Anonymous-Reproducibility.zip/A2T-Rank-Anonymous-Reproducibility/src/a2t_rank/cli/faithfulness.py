from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
import torch
from torch.utils.data import DataLoader

from a2t_rank.config import load_yaml
from a2t_rank.data.dataset import APDDv2Dataset, category_mapping, load_partition
from a2t_rank.metrics import regression_metrics
from a2t_rank.models import A2TRank
from a2t_rank.utils import seed_everything, write_json


@torch.inference_mode()
def score(model, loader, device, removal, amp_enabled):
    targets = []
    predictions = []
    identifiers = []
    model.eval()
    for batch in loader:
        images = batch["image"].to(device, non_blocking=True)
        with torch.autocast(device_type=device.type, enabled=amp_enabled):
            outputs = model(images, attribute_removal=removal)
        targets.extend(batch["target"].numpy().tolist())
        predictions.extend(outputs["mean"].float().cpu().numpy().tolist())
        identifiers.extend(batch["sample_id"])
    return pd.DataFrame({"sample_id": identifiers, "y_true": targets, "y_pred": predictions})


def main() -> None:
    parser = argparse.ArgumentParser(description="Run attribute-removal faithfulness checks")
    parser.add_argument("--config", type=Path, default=Path("configs/a2t_rank.yaml"))
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--prompt-bank", type=Path, required=True)
    parser.add_argument("--fold", type=int, choices=range(1, 6), required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    seed_everything(arguments.seed, True)
    config = load_yaml(arguments.config)
    manifest_path = Path(config["data"]["manifest"])
    split_path = Path(config["data"]["split_dir"]) / f"outer_fold_{arguments.fold}.csv"
    manifest = pd.read_csv(manifest_path)
    table = load_partition(manifest_path, split_path, "test")
    dataset = APDDv2Dataset(
        table,
        Path(config["data"]["image_root"]),
        category_mapping(manifest),
        training=False,
        image_size=int(config["experiment"]["image_size"]),
    )
    loader = DataLoader(
        dataset,
        batch_size=int(config["train"]["batch_size"]),
        shuffle=False,
        num_workers=int(config["train"]["num_workers"]),
        pin_memory=True,
    )
    prompt_payload = torch.load(arguments.prompt_bank, map_location="cpu", weights_only=True)
    prompts = prompt_payload["queries"] if isinstance(prompt_payload, dict) else prompt_payload
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = A2TRank(config, prompts).to(device)
    checkpoint = torch.load(arguments.checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model_state"])
    amp_enabled = bool(config["train"]["amp"]) and device.type == "cuda"
    tables = {
        rule: score(model, loader, device, None if rule == "none" else rule, amp_enabled)
        for rule in ("none", "highest", "random", "lowest")
    }
    baseline = regression_metrics(tables["none"]["y_true"], tables["none"]["y_pred"])["srocc"]
    result = {
        "status": "executed",
        "baseline_srocc": baseline,
        "srocc_change": {
            rule: regression_metrics(frame["y_true"], frame["y_pred"])["srocc"] - baseline
            for rule, frame in tables.items()
            if rule != "none"
        },
        "ordering_holds": False,
    }
    changes = result["srocc_change"]
    result["ordering_holds"] = bool(changes["highest"] <= changes["random"] <= changes["lowest"])
    write_json(arguments.output, result)
    print(result)


if __name__ == "__main__":
    main()
