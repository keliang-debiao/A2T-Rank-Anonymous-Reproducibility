from __future__ import annotations

from typing import Any

import timm
import torch
import torch.nn.functional as F
from torch import nn
from transformers import CLIPVisionModel

from a2t_rank.models.components import (
    CrossAttentionBlock,
    FactorBranch,
    PredictionHead,
    inject_convnext_adapters,
    reverse_gradient,
)
from a2t_rank.models.lora import inject_clip_lora
from a2t_rank.prompts import OVERALL_INDEX, TRANSFER_ATTRIBUTE_COUNT


class A2TRankCore(nn.Module):
    def __init__(self, config: dict[str, Any], prompt_bank: torch.Tensor) -> None:
        super().__init__()
        model = config["model"]
        dim = int(model["common_dim"])
        self.dim = dim
        self.use_structural = bool(model["use_structural_stream"])
        self.use_cross_attention = bool(model["use_cross_attention"])
        self.use_attribute_supervision = bool(model["use_attribute_supervision"])
        self.use_reliability = bool(model["use_reliability"])
        self.use_dynamic_aggregation = bool(model["use_dynamic_aggregation"])
        self.use_style_specific = bool(model["use_style_specific"])
        self.use_style_invariant = bool(model["use_style_invariant"])
        self.include_overall = bool(model["include_overall_in_transfer"])
        self.aggregation_temperature = float(model["aggregation_temperature"])
        self.register_buffer(
            "prompt_bank", F.normalize(prompt_bank.float(), dim=-1), persistent=True
        )

        self.clip_global_projection = nn.Linear(1024, dim)
        self.clip_token_projection = nn.Linear(1024, dim)
        self.conv_global_projection = nn.Linear(1024, dim)
        self.conv_token_projection = nn.Linear(1024, dim)
        self.fusion = nn.Linear(dim * 2, dim)
        self.fusion_norm = nn.LayerNorm(dim)
        self.global_query_adapter = nn.Linear(dim, dim)
        self.cross_attention = nn.ModuleList(
            [
                CrossAttentionBlock(
                    dim,
                    int(model["attention_heads"]),
                    int(model["ffn_dim"]),
                    float(model["attention_dropout"]),
                )
                for _ in range(int(model["attention_layers"]))
            ]
        )
        self.style_specific = FactorBranch(dim)
        self.style_invariant = FactorBranch(dim)
        categories = int(model["categories"])
        self.category_specific = nn.Linear(dim, categories)
        self.category_invariant = nn.Linear(dim, categories)
        self.attribute_heads = nn.ModuleList(
            [nn.Sequential(nn.Linear(dim, 128), nn.GELU(), nn.Linear(128, 1)) for _ in range(10)]
        )
        self.reliability = nn.Linear(dim * 2, 1)
        self.attribute_weight = nn.Linear(dim, 1)
        self.score_head = PredictionHead(dim * 4, float(model["head_dropout"]))
        self.logvar_head = PredictionHead(dim * 4, float(model["head_dropout"]))

    def forward(
        self,
        clip_tokens: torch.Tensor,
        clip_global: torch.Tensor,
        conv_tokens: torch.Tensor,
        conv_global: torch.Tensor,
        attribute_removal: str | None = None,
    ) -> dict[str, torch.Tensor]:
        clip_global_projected = self.clip_global_projection(clip_global)
        if self.use_structural:
            conv_global_projected = self.conv_global_projection(conv_global)
            conv_projected = self.conv_token_projection(conv_tokens)
        else:
            conv_global_projected = torch.zeros_like(clip_global_projected)
            conv_projected = torch.zeros(
                clip_tokens.shape[0],
                121,
                self.dim,
                device=clip_tokens.device,
                dtype=clip_tokens.dtype,
            )
        h = self.fusion_norm(
            self.fusion(torch.cat([clip_global_projected, conv_global_projected], dim=-1))
        )
        clip_projected = self.clip_token_projection(clip_tokens)
        visual_tokens = torch.cat([clip_projected, conv_projected, h.unsqueeze(1)], dim=1)

        queries = self.prompt_bank.unsqueeze(0).expand(h.shape[0], -1, -1)
        attention_maps: list[torch.Tensor] = []
        if self.use_cross_attention:
            for block in self.cross_attention:
                queries, weights = block(queries, visual_tokens)
                attention_maps.append(weights)
        else:
            queries = queries + self.global_query_adapter(h).unsqueeze(1)

        attribute_predictions = torch.cat(
            [
                head(queries[:, index]).squeeze(-1).unsqueeze(1)
                for index, head in enumerate(self.attribute_heads)
            ],
            dim=1,
        )
        s = self.style_specific(h) if self.use_style_specific else torch.zeros_like(h)
        z = self.style_invariant(h) if self.use_style_invariant else torch.zeros_like(h)
        category_specific = self.category_specific(s)
        category_invariant = self.category_invariant(reverse_gradient(z, 1.0))

        transfer_count = 10 if self.include_overall else TRANSFER_ATTRIBUTE_COUNT
        transfer_queries = queries[:, :transfer_count]
        repeated_h = h.unsqueeze(1).expand(-1, transfer_count, -1)
        reliability = torch.sigmoid(
            self.reliability(torch.cat([transfer_queries, repeated_h], dim=-1)).squeeze(-1)
        )
        if not self.use_reliability:
            reliability = torch.ones_like(reliability)
        if self.use_dynamic_aggregation:
            logits = (
                self.attribute_weight(transfer_queries).squeeze(-1) / self.aggregation_temperature
            )
            if self.use_reliability:
                logits = logits + torch.log(reliability.clamp_min(1e-8))
            aggregation = torch.softmax(logits, dim=1)
        else:
            aggregation = torch.full_like(reliability, 1.0 / transfer_count)
        if attribute_removal is not None:
            if attribute_removal == "highest":
                removed = aggregation.argmax(dim=1)
            elif attribute_removal == "lowest":
                removed = aggregation.argmin(dim=1)
            elif attribute_removal == "random":
                removed = torch.randint(
                    0, transfer_count, (aggregation.shape[0],), device=aggregation.device
                )
            else:
                raise ValueError(f"Unknown attribute removal rule: {attribute_removal}")
            keep = torch.ones_like(aggregation)
            keep.scatter_(1, removed.unsqueeze(1), 0.0)
            aggregation = aggregation * keep
            aggregation = aggregation / aggregation.sum(dim=1, keepdim=True).clamp_min(1e-8)

        aggregation_queries = transfer_queries
        if not self.include_overall:
            aggregation_queries = aggregation_queries[:, :OVERALL_INDEX]
        v_attribute = torch.sum(aggregation.unsqueeze(-1) * aggregation_queries, dim=1)
        if not self.use_attribute_supervision and not self.use_cross_attention:
            v_attribute = torch.zeros_like(v_attribute)
        combined = torch.cat([h, s, z, v_attribute], dim=-1)
        result = {
            "mean": self.score_head(combined),
            "logvar": self.logvar_head(combined).clamp(-10.0, 10.0),
            "attributes": attribute_predictions,
            "reliability": reliability,
            "aggregation": aggregation,
            "queries": queries,
            "global": h,
            "style_specific": s,
            "style_invariant": z,
            "category_specific": category_specific,
            "category_invariant": category_invariant,
            "prompt_bank": self.prompt_bank,
        }
        if attention_maps:
            result["attention"] = torch.stack(attention_maps, dim=1)
        return result


class A2TRank(nn.Module):
    clip_mean = (0.48145466, 0.4578275, 0.40821073)
    clip_std = (0.26862954, 0.26130258, 0.27577711)
    imagenet_mean = (0.485, 0.456, 0.406)
    imagenet_std = (0.229, 0.224, 0.225)

    def __init__(self, config: dict[str, Any], prompt_bank: torch.Tensor) -> None:
        super().__init__()
        model = config["model"]
        self.clip = CLIPVisionModel.from_pretrained(model["clip_checkpoint"])
        for parameter in self.clip.parameters():
            parameter.requires_grad = False
        inject_clip_lora(
            self.clip,
            int(model["lora_rank"]),
            int(model["lora_alpha"]),
            float(model["lora_dropout"]),
            int(model["lora_top_blocks"]),
        )
        self.convnext = timm.create_model(
            model["convnext_checkpoint"], pretrained=True, num_classes=0, global_pool=""
        )
        for parameter in self.convnext.parameters():
            parameter.requires_grad = False
        inject_convnext_adapters(self.convnext)
        self.conv_adapter = nn.Sequential(
            nn.Conv2d(1024, 256, 1), nn.GELU(), nn.Conv2d(256, 1024, 1)
        )
        self.core = A2TRankCore(config, prompt_bank)
        self.register_buffer("clip_mean_tensor", torch.tensor(self.clip_mean).view(1, 3, 1, 1))
        self.register_buffer("clip_std_tensor", torch.tensor(self.clip_std).view(1, 3, 1, 1))
        self.register_buffer(
            "imagenet_mean_tensor", torch.tensor(self.imagenet_mean).view(1, 3, 1, 1)
        )
        self.register_buffer(
            "imagenet_std_tensor", torch.tensor(self.imagenet_std).view(1, 3, 1, 1)
        )

    def forward(
        self, images: torch.Tensor, attribute_removal: str | None = None
    ) -> dict[str, torch.Tensor]:
        clip_pixels = (images - self.clip_mean_tensor) / self.clip_std_tensor
        clip_output = self.clip(pixel_values=clip_pixels, return_dict=True)
        clip_tokens = clip_output.last_hidden_state[:, 1:]
        clip_global = clip_output.pooler_output

        if self.core.use_structural:
            conv_pixels = (images - self.imagenet_mean_tensor) / self.imagenet_std_tensor
            conv_base = self.convnext(conv_pixels)
            conv_map = conv_base + self.conv_adapter(conv_base)
            conv_tokens = conv_map.flatten(2).transpose(1, 2)
            if conv_tokens.shape[1] != 121:
                conv_map = F.adaptive_avg_pool2d(conv_map, (11, 11))
                conv_tokens = conv_map.flatten(2).transpose(1, 2)
            conv_global = conv_map.mean(dim=(2, 3))
        else:
            conv_tokens = images.new_zeros(images.shape[0], 121, 1024)
            conv_global = images.new_zeros(images.shape[0], 1024)
        return self.core(
            clip_tokens,
            clip_global,
            conv_tokens,
            conv_global,
            attribute_removal=attribute_removal,
        )
