from __future__ import annotations

import argparse
from pathlib import Path

import torch

from a2t_rank.config import load_yaml
from a2t_rank.metrics import regression_metrics
from a2t_rank.models.baselines import baseline_loss, build_baseline
from a2t_rank.prediction import predict_loader, save_predictions
from a2t_rank.training import _make_loaders
from a2t_rank.utils import seed_everything, sha256_file, write_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Train one controlled baseline seed-fold job")
    parser.add_argument("--config", type=Path, default=Path("configs/a2t_rank.yaml"))
    parser.add_argument("--baseline-config", type=Path, default=Path("configs/baselines.yaml"))
    parser.add_argument("--baseline", required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--fold", type=int, choices=range(1, 6), required=True)
    arguments = parser.parse_args()
    config = load_yaml(arguments.config)
    baseline_map = load_yaml(arguments.baseline_config)
    if arguments.baseline not in baseline_map:
        raise SystemExit(f"Unknown baseline: {arguments.baseline}")
    settings = baseline_map[arguments.baseline]
    if arguments.seed not in config["experiment"]["seeds"]:
        raise SystemExit("Seed is outside the locked protocol")
    seed_everything(arguments.seed, True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    train_loader, validation_loader, test_loader, _ = _make_loaders(
        config, arguments.fold, arguments.seed
    )
    model = build_baseline(settings).to(device)
    optimizer = torch.optim.AdamW(
        [parameter for parameter in model.parameters() if parameter.requires_grad],
        lr=float(settings["learning_rate"]),
        weight_decay=float(config["train"]["weight_decay"]),
    )
    amp_enabled = bool(config["train"]["amp"]) and device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=amp_enabled)
    best_srocc = -float("inf")
    best_epoch = 0
    patience = 0
    run_name = f"{arguments.baseline}_seed{arguments.seed}_fold{arguments.fold}"
    root = Path(config["output"]["root"])
    checkpoint_path = root / "checkpoints" / run_name / "best.pt"
    checkpoint_path.parent.mkdir(parents=True, exist_ok=True)

    for epoch in range(1, int(settings["epochs"]) + 1):
        model.train()
        for batch in train_loader:
            images = batch["image"].to(device, non_blocking=True)
            target = batch["target"].to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, enabled=amp_enabled):
                outputs = model(images)
                loss = baseline_loss(outputs, target)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
        validation = predict_loader(model, validation_loader, device, amp_enabled)
        score = regression_metrics(validation["y_true"], validation["y_pred"])["srocc"]
        if score > best_srocc:
            best_srocc = score
            best_epoch = epoch
            patience = 0
            torch.save(
                {
                    "model_state": model.state_dict(),
                    "epoch": epoch,
                    "seed": arguments.seed,
                    "fold": arguments.fold,
                    "baseline": arguments.baseline,
                },
                checkpoint_path,
            )
        else:
            patience += 1
            if patience >= int(config["train"]["early_stopping_patience"]):
                break

    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model_state"])
    test = predict_loader(model, test_loader, device, amp_enabled)
    output = root / "predictions" / f"outer_{run_name}.csv"
    save_predictions(test, output)
    summary = {
        "status": "executed",
        "baseline": arguments.baseline,
        "seed": arguments.seed,
        "fold": arguments.fold,
        "best_epoch": best_epoch,
        "checkpoint_sha256": sha256_file(checkpoint_path),
        "metrics": regression_metrics(test["y_true"], test["y_pred"]),
    }
    write_json(root / "metrics" / f"{run_name}.json", summary)
    print(summary)


if __name__ == "__main__":
    main()
