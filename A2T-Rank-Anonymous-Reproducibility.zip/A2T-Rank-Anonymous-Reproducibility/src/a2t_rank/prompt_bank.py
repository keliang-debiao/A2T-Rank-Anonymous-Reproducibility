from __future__ import annotations

import platform
from pathlib import Path

import torch
import torch.nn.functional as F
from transformers import CLIPTextModelWithProjection, CLIPTokenizerFast

from a2t_rank.prompts import ATTRIBUTE_NAMES, PROMPT_PAIRS, validate_prompt_bank
from a2t_rank.utils import sha256_file, write_json


def build_prompt_bank(
    output: Path,
    metadata: Path,
    checkpoint: str = "openai/clip-vit-large-patch14-336",
    revision: str = "main",
    projection_seed: int = 2026,
) -> dict[str, object]:
    validate_prompt_bank()
    tokenizer = CLIPTokenizerFast.from_pretrained(checkpoint, revision=revision)
    encoder = CLIPTextModelWithProjection.from_pretrained(checkpoint, revision=revision)
    encoder.eval()
    for parameter in encoder.parameters():
        parameter.requires_grad = False
    positive = [pair[0] for pair in PROMPT_PAIRS]
    negative = [pair[1] for pair in PROMPT_PAIRS]
    encoded = tokenizer(positive + negative, padding=True, truncation=True, return_tensors="pt")
    with torch.inference_mode():
        embeddings = encoder(**encoded).text_embeds.float()
    difference = embeddings[:10] - embeddings[10:]
    generator = torch.Generator().manual_seed(projection_seed)
    random_matrix = torch.randn(difference.shape[1], 512, generator=generator)
    projection, _ = torch.linalg.qr(random_matrix, mode="reduced")
    queries = F.normalize(difference @ projection, dim=-1)
    output.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "queries": queries.cpu(),
            "projection_seed": projection_seed,
            "checkpoint": checkpoint,
            "revision": revision,
        },
        output,
    )
    record: dict[str, object] = {
        "status": "executed",
        "checkpoint": checkpoint,
        "revision": revision,
        "projection": "seeded_gaussian_qr",
        "projection_seed": projection_seed,
        "attributes": list(ATTRIBUTE_NAMES),
        "prompt_pairs": [list(pair) for pair in PROMPT_PAIRS],
        "tensor_shape": list(queries.shape),
        "artifact_sha256": sha256_file(output),
        "torch_version": torch.__version__,
        "python_version": platform.python_version(),
    }
    write_json(metadata, record)
    return record
