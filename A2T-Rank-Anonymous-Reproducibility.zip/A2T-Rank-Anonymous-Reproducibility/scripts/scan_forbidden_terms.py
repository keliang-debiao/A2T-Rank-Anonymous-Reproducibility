from __future__ import annotations

import argparse
from pathlib import Path

from a2t_rank.release import scan_terms


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Scan names and text for disallowed release tokens"
    )
    parser.add_argument("root", nargs="?", type=Path, default=Path("."))
    arguments = parser.parse_args()
    findings = scan_terms(arguments.root.resolve())
    if findings:
        print("\n".join(findings))
        raise SystemExit(1)
    print("Token scan passed")


if __name__ == "__main__":
    main()
