from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


def test_reference_records_are_explicitly_unverified() -> None:
    root = Path("reference_records")
    status_value = "reference_values_pending_empirical_reproduction"
    status = json.loads((root / "STATUS.json").read_text(encoding="utf-8"))
    assert status["artifact_status"] == status_value
    table = pd.read_csv(root / "main_seed_fold_metrics.csv")
    assert len(table) == 25
    assert set(table["record_status"]) == {status_value}
