#!/usr/bin/env bash
set -euo pipefail

seed="${1:?A locked seed is required}"
for fold in 1 2 3 4 5; do
  a2t-train --config configs/a2t_rank.yaml --seed "$seed" --fold "$fold"
done

