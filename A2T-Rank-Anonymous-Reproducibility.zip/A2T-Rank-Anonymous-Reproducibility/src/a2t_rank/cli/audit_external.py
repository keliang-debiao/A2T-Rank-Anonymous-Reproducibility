from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from a2t_rank.data.audit import (
    candidate_table,
    embedding_candidates,
    exact_candidates,
    metadata_candidates,
    phash_candidates,
)
from a2t_rank.utils import write_json


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Audit APDDv2-to-external contamination candidates"
    )
    parser.add_argument("--apddv2-manifest", type=Path, required=True)
    parser.add_argument("--external-manifest", type=Path, required=True)
    parser.add_argument("--external-name", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--review-file", type=Path)
    parser.add_argument("--combined-embedding-npz", type=Path)
    parser.add_argument("--phash-threshold", type=int, default=6)
    parser.add_argument("--embedding-threshold", type=float, default=0.985)
    arguments = parser.parse_args()

    development = pd.read_csv(arguments.apddv2_manifest, dtype={"sample_id": str})
    external = pd.read_csv(arguments.external_manifest, dtype={"sample_id": str})
    development_prefix = "apddv2:"
    external_prefix = "external:"
    development["sample_id"] = development_prefix + development["sample_id"].astype(str)
    external["sample_id"] = external_prefix + external["sample_id"].astype(str)
    combined = pd.concat([development, external], ignore_index=True, sort=False).fillna("")
    pairs = exact_candidates(combined) + metadata_candidates(combined)
    pairs += phash_candidates(combined, arguments.phash_threshold)
    if arguments.combined_embedding_npz:
        pairs += embedding_candidates(
            arguments.combined_embedding_npz, arguments.embedding_threshold
        )
    candidates = candidate_table(pairs)
    cross = candidates.loc[
        candidates["left_id"].str.startswith(development_prefix)
        != candidates["right_id"].str.startswith(development_prefix)
    ].copy()

    def normalize_pair(row):
        if str(row.left_id).startswith(development_prefix):
            return (
                str(row.left_id)[len(development_prefix) :],
                str(row.right_id)[len(external_prefix) :],
            )
        return (
            str(row.right_id)[len(development_prefix) :],
            str(row.left_id)[len(external_prefix) :],
        )

    normalized = [normalize_pair(row) for row in cross.itertuples(index=False)]
    cross["apddv2_sample_id"] = [value[0] for value in normalized]
    cross["external_id"] = [value[1] for value in normalized]
    cross["external_dataset"] = arguments.external_name
    cross = cross.rename(columns={"basis": "match_basis"})
    columns = [
        "external_dataset",
        "external_id",
        "apddv2_sample_id",
        "match_basis",
        "value",
        "auto_accept",
        "review_status",
    ]
    cross = cross[columns].drop_duplicates(["external_id", "apddv2_sample_id", "match_basis"])
    if arguments.review_file:
        review = pd.read_csv(
            arguments.review_file,
            dtype={"external_id": str, "apddv2_sample_id": str},
        )
        keys = ["external_id", "apddv2_sample_id", "match_basis"]
        cross = cross.drop(columns="review_status").merge(
            review[keys + ["review_status"]], on=keys, how="left"
        )
        cross["review_status"] = cross["review_status"].fillna(
            cross["auto_accept"].map({True: "accepted", False: "pending_manual_review"})
        )
    allowed = {"accepted", "rejected", "pending_manual_review"}
    unexpected = set(cross["review_status"].astype(str)) - allowed
    if unexpected:
        raise ValueError(f"Unexpected review status values: {sorted(unexpected)}")
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    cross.to_csv(arguments.output, index=False)
    pending = int((cross["review_status"] == "pending_manual_review").sum())
    accepted = int((cross["review_status"] == "accepted").sum())
    write_json(
        arguments.output.with_suffix(".status.json"),
        {
            "status": "complete" if pending == 0 else "pending_manual_review",
            "external_dataset": arguments.external_name,
            "candidate_pairs": len(cross),
            "accepted_pairs": accepted,
            "pending_pairs": pending,
        },
    )
    if pending:
        raise SystemExit(f"{pending} cross-dataset candidates require manual review")
    print(f"External audit complete with {accepted} accepted exclusions")


if __name__ == "__main__":
    main()
