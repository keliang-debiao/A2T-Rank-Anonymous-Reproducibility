from __future__ import annotations

import argparse
from pathlib import Path

from a2t_rank.data.prepare import prepare_apddv2


def main() -> None:
    parser = argparse.ArgumentParser(description="Normalize APDDv2 annotations and inspect images")
    parser.add_argument("--annotations", type=Path, required=True)
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    table = prepare_apddv2(arguments.annotations, arguments.image_root, arguments.output)
    decoded = int(table["decode_ok"].sum())
    if decoded != len(table):
        raise SystemExit(
            f"Prepared {len(table)} rows, but only {decoded} images decoded successfully"
        )
    print(f"Prepared {len(table)} APDDv2 rows at {arguments.output}")


if __name__ == "__main__":
    main()
