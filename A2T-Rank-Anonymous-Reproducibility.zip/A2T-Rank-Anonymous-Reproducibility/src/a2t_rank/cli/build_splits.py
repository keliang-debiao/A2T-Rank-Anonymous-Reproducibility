from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from a2t_rank.data.splits import build_nested_splits


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Create group-disjoint nested cross-validation splits"
    )
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=2026)
    arguments = parser.parse_args()
    table = pd.read_csv(arguments.manifest, dtype={"sample_id": str, "group_id": str})
    paths = build_nested_splits(table, arguments.output_dir, arguments.seed)
    for path in paths:
        split = pd.read_csv(path)
        counts = split["role"].value_counts().to_dict()
        print(path, counts)


if __name__ == "__main__":
    main()
