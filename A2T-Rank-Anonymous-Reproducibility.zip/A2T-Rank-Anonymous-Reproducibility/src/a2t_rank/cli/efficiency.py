from __future__ import annotations

import argparse
import time
from pathlib import Path

import numpy as np
import torch

from a2t_rank.config import load_yaml
from a2t_rank.models import A2TRank
from a2t_rank.utils import count_parameters, write_json


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Measure parameters, latency, throughput, and memory"
    )
    parser.add_argument("--config", type=Path, default=Path("configs/a2t_rank.yaml"))
    parser.add_argument("--prompt-bank", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--warmup", type=int, default=100)
    parser.add_argument("--runs", type=int, default=1000)
    arguments = parser.parse_args()
    if not torch.cuda.is_available():
        raise SystemExit("Efficiency measurement requires CUDA for the stated protocol")
    config = load_yaml(arguments.config)
    payload = torch.load(arguments.prompt_bank, map_location="cpu", weights_only=True)
    prompts = payload["queries"] if isinstance(payload, dict) else payload
    device = torch.device("cuda")
    model = A2TRank(config, prompts).to(device).eval().half()
    if arguments.checkpoint:
        checkpoint = torch.load(arguments.checkpoint, map_location=device, weights_only=False)
        model.load_state_dict(checkpoint["model_state"])
    total, trainable = count_parameters(model)
    image = torch.zeros(1, 3, 336, 336, device=device, dtype=torch.float16)
    torch.cuda.reset_peak_memory_stats()
    with torch.inference_mode(), torch.autocast("cuda", dtype=torch.float16):
        for _ in range(arguments.warmup):
            model(image)
        torch.cuda.synchronize()
        elapsed = []
        for _ in range(arguments.runs):
            start = time.perf_counter()
            model(image)
            torch.cuda.synchronize()
            elapsed.append((time.perf_counter() - start) * 1000)
    batch = torch.zeros(32, 3, 336, 336, device=device, dtype=torch.float16)
    with torch.inference_mode(), torch.autocast("cuda", dtype=torch.float16):
        for _ in range(20):
            model(batch)
        torch.cuda.synchronize()
        start = time.perf_counter()
        for _ in range(100):
            model(batch)
        torch.cuda.synchronize()
        throughput = 3200 / (time.perf_counter() - start)
    elapsed_array = np.asarray(elapsed)
    rng = np.random.default_rng(2026)
    bootstrap_means = np.empty(10_000, dtype=float)
    for index in range(len(bootstrap_means)):
        bootstrap_means[index] = rng.choice(
            elapsed_array, size=len(elapsed_array), replace=True
        ).mean()
    result = {
        "status": "executed",
        "total_parameters": total,
        "trainable_parameters": trainable,
        "latency_ms_mean": float(elapsed_array.mean()),
        "latency_ms_p95": float(np.quantile(elapsed_array, 0.95)),
        "latency_ms_bootstrap_ci_95": [
            float(np.quantile(bootstrap_means, 0.025)),
            float(np.quantile(bootstrap_means, 0.975)),
        ],
        "throughput_images_per_second_batch32": float(throughput),
        "peak_inference_memory_gb": float(torch.cuda.max_memory_allocated() / 1024**3),
        "warmup_runs": arguments.warmup,
        "timed_runs": arguments.runs,
        "disk_io_included": False,
    }
    write_json(arguments.output, result)
    print(result)


if __name__ == "__main__":
    main()
