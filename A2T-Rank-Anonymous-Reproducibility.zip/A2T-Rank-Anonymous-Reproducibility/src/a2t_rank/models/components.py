from __future__ import annotations

import torch
from torch import nn


class GradientReversal(torch.autograd.Function):
    @staticmethod
    def forward(ctx: object, inputs: torch.Tensor, coefficient: float) -> torch.Tensor:
        ctx.coefficient = coefficient
        return inputs.view_as(inputs)

    @staticmethod
    def backward(ctx: object, gradient: torch.Tensor) -> tuple[torch.Tensor, None]:
        return -ctx.coefficient * gradient, None


def reverse_gradient(inputs: torch.Tensor, coefficient: float = 1.0) -> torch.Tensor:
    return GradientReversal.apply(inputs, coefficient)


class CrossAttentionBlock(nn.Module):
    def __init__(self, dim: int, heads: int, ffn_dim: int, dropout: float) -> None:
        super().__init__()
        self.attention = nn.MultiheadAttention(dim, heads, dropout=dropout, batch_first=True)
        self.attention_norm = nn.LayerNorm(dim)
        self.ffn = nn.Sequential(
            nn.Linear(dim, ffn_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(ffn_dim, dim),
            nn.Dropout(dropout),
        )
        self.ffn_norm = nn.LayerNorm(dim)

    def forward(
        self, queries: torch.Tensor, tokens: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        attended, weights = self.attention(
            queries,
            tokens,
            tokens,
            need_weights=True,
            average_attn_weights=False,
        )
        queries = self.attention_norm(queries + attended)
        queries = self.ffn_norm(queries + self.ffn(queries))
        return queries, weights


class FactorBranch(nn.Module):
    def __init__(self, dim: int) -> None:
        super().__init__()
        self.net = nn.Sequential(nn.Linear(dim, dim), nn.GELU(), nn.LayerNorm(dim))

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return self.net(inputs)


class PredictionHead(nn.Module):
    def __init__(self, input_dim: int, dropout: float) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 1024),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(1024, 256),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(256, 1),
        )

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return self.net(inputs).squeeze(-1)


class ConvNeXtBlockAdapter(nn.Module):
    def __init__(self, base_block: nn.Module, channels: int) -> None:
        super().__init__()
        self.base_block = base_block
        for parameter in self.base_block.parameters():
            parameter.requires_grad = False
        bottleneck = max(1, channels // 2)
        self.adapter = nn.Sequential(
            nn.Conv2d(channels, bottleneck, 1),
            nn.GELU(),
            nn.Conv2d(bottleneck, channels, 1),
        )
        nn.init.zeros_(self.adapter[-1].weight)
        nn.init.zeros_(self.adapter[-1].bias)

    def train(self, mode: bool = True):
        super().train(mode)
        self.base_block.eval()
        return self

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        base = self.base_block(inputs)
        return base + self.adapter(base)


def inject_convnext_adapters(
    model: nn.Module, widths: tuple[int, ...] = (128, 256, 512, 1024)
) -> None:
    if len(model.stages) != len(widths):
        raise ValueError("Unexpected ConvNeXt stage count")
    for stage, channels in zip(model.stages, widths, strict=True):
        for index, block in enumerate(stage.blocks):
            stage.blocks[index] = ConvNeXtBlockAdapter(block, channels)
