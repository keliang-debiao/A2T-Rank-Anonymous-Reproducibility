from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Assemble seed-level and five-seed OOF predictions"
    )
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    arguments = parser.parse_args()
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    seed_tables = []
    for seed in range(2026, 2031):
        paths = [arguments.input_dir / f"outer_seed{seed}_fold{fold}.csv" for fold in range(1, 6)]
        missing = [path for path in paths if not path.is_file()]
        if missing:
            raise SystemExit(f"Missing outer predictions for seed {seed}: {missing}")
        table = pd.concat(
            [pd.read_csv(path, dtype={"sample_id": str}) for path in paths], ignore_index=True
        )
        if table["sample_id"].duplicated().any():
            raise ValueError(f"Seed {seed} has duplicate OOF sample identifiers")
        table["seed"] = seed
        table.to_csv(arguments.output_dir / f"oof_seed{seed}.csv", index=False)
        seed_tables.append(table)
    long_table = pd.concat(seed_tables, ignore_index=True)
    long_table.to_csv(arguments.output_dir / "oof_all_seed_rows.csv", index=False)
    invariant = ["sample_id", "group_id", "y_true"]
    numeric = [
        column
        for column in long_table.select_dtypes(include="number").columns
        if column not in {"seed", "y_true"}
    ]
    averaged = long_table.groupby(invariant, as_index=False)[numeric].mean()
    averaged.to_csv(arguments.output_dir / "oof_five_seed_ensemble.csv", index=False)
    print(f"Wrote {len(long_table)} seed rows and {len(averaged)} ensemble rows")


if __name__ == "__main__":
    main()
