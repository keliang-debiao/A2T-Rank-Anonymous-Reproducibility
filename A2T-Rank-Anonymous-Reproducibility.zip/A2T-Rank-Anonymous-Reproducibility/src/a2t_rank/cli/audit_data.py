from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from a2t_rank.data.audit import (
    CandidatePair,
    assign_groups,
    candidate_table,
    embedding_candidates,
    exact_candidates,
    metadata_candidates,
    phash_candidates,
)
from a2t_rank.utils import write_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Build reviewed connected duplicate groups")
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output-manifest", type=Path, required=True)
    parser.add_argument("--pairs-output", type=Path, required=True)
    parser.add_argument("--review-file", type=Path)
    parser.add_argument("--embedding-npz", type=Path)
    parser.add_argument("--phash-threshold", type=int, default=6)
    parser.add_argument("--embedding-threshold", type=float, default=0.985)
    arguments = parser.parse_args()

    table = pd.read_csv(arguments.manifest, dtype={"sample_id": str})
    pairs = exact_candidates(table) + metadata_candidates(table)
    pairs += phash_candidates(table, arguments.phash_threshold)
    if arguments.embedding_npz:
        pairs += embedding_candidates(arguments.embedding_npz, arguments.embedding_threshold)
    candidates = candidate_table(pairs).drop_duplicates(["left_id", "right_id", "basis"])

    if arguments.review_file:
        review = pd.read_csv(arguments.review_file, dtype={"left_id": str, "right_id": str})
        required = {"left_id", "right_id", "basis", "review_status"}
        missing = required - set(review.columns)
        if missing:
            raise ValueError(f"Review file is missing columns: {sorted(missing)}")
        candidates = candidates.drop(columns="review_status").merge(
            review[["left_id", "right_id", "basis", "review_status"]],
            on=["left_id", "right_id", "basis"],
            how="left",
        )
        candidates["review_status"] = candidates["review_status"].fillna(
            candidates["auto_accept"].map({True: "accepted", False: "pending_manual_review"})
        )

    allowed_status = {"accepted", "rejected", "pending_manual_review"}
    unexpected = set(candidates["review_status"].astype(str)) - allowed_status
    if unexpected:
        raise ValueError(f"Unexpected review status values: {sorted(unexpected)}")

    accepted = [
        CandidatePair(
            str(row.left_id),
            str(row.right_id),
            str(row.basis),
            row.value,
            bool(row.auto_accept),
        )
        for row in candidates.itertuples(index=False)
        if str(row.review_status) == "accepted"
    ]
    pending = int((candidates["review_status"] == "pending_manual_review").sum())
    grouped = assign_groups(table, accepted)
    grouped["duplicate_audit_complete"] = pending == 0
    arguments.output_manifest.parent.mkdir(parents=True, exist_ok=True)
    arguments.pairs_output.parent.mkdir(parents=True, exist_ok=True)
    grouped.to_csv(arguments.output_manifest, index=False)
    candidates.to_csv(arguments.pairs_output, index=False)
    write_json(
        arguments.pairs_output.with_suffix(".status.json"),
        {
            "status": "complete" if pending == 0 else "pending_manual_review",
            "candidate_pairs": len(candidates),
            "accepted_pairs": len(accepted),
            "pending_pairs": pending,
            "groups": int(grouped["group_id"].nunique()),
        },
    )
    if pending:
        raise SystemExit(
            f"Wrote {len(candidates)} candidates; {pending} require review before split construction"
        )
    print(f"Duplicate audit complete with {grouped['group_id'].nunique()} connected groups")


if __name__ == "__main__":
    main()
