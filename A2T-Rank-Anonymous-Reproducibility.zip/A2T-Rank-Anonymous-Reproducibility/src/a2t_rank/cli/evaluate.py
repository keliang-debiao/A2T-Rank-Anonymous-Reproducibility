from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from a2t_rank.metrics import (
    attribute_metrics,
    gaussian_calibration_metrics,
    regression_metrics,
    reliability_diagnostics,
    vab_set_metrics,
)
from a2t_rank.prompts import ATTRIBUTE_NAMES
from a2t_rank.utils import write_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Recompute scalar or set-ranking metrics")
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mode", choices=("scalar", "vab"), default="scalar")
    parser.add_argument("--tasks", type=Path)
    parser.add_argument("--exclusions", type=Path)
    arguments = parser.parse_args()
    predictions = pd.read_csv(arguments.predictions, dtype={"sample_id": str})
    if arguments.exclusions:
        exclusions = pd.read_csv(arguments.exclusions, dtype={"external_id": str})
        predictions = predictions.loc[~predictions["sample_id"].isin(exclusions["external_id"])]

    if arguments.mode == "vab":
        if not arguments.tasks:
            raise SystemExit("--tasks is required for VAB set-ranking evaluation")
        tasks = pd.read_csv(arguments.tasks, dtype={"candidate_id": str})
        joined = tasks.merge(
            predictions[["sample_id", "y_pred"]],
            left_on="candidate_id",
            right_on="sample_id",
            how="inner",
            validate="many_to_one",
        ).rename(columns={"y_pred": "score"})
        result: dict[str, object] = vab_set_metrics(joined)
    else:
        prediction_column = "y_pred_cal" if "y_pred_cal" in predictions else "y_pred"
        logvar_column = "logvar_cal" if "logvar_cal" in predictions else "logvar"
        result = {
            "regression": regression_metrics(predictions["y_true"], predictions[prediction_column])
        }
        if logvar_column in predictions:
            result["calibration"] = gaussian_calibration_metrics(
                predictions["y_true"].to_numpy(),
                predictions[prediction_column].to_numpy(),
                predictions[logvar_column].to_numpy(),
            )
        if "reliability_mean" in predictions:
            result["reliability"] = reliability_diagnostics(predictions)
        if all(f"attr_pred_{index}" in predictions for index in range(10)):
            attributes, macro = attribute_metrics(predictions, list(ATTRIBUTE_NAMES))
            result["attribute_macro"] = macro
            result["attribute_rows"] = attributes.to_dict(orient="records")
    write_json(arguments.output, result)
    print(result)


if __name__ == "__main__":
    main()
