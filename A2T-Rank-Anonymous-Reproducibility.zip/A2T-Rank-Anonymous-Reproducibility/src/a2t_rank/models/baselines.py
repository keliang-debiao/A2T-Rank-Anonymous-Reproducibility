from __future__ import annotations

from typing import Any

import timm
import torch
import torch.nn.functional as F
from torch import nn
from transformers import CLIPVisionModel


class TimmRegressor(nn.Module):
    def __init__(self, checkpoint: str) -> None:
        super().__init__()
        self.backbone = timm.create_model(
            checkpoint, pretrained=True, num_classes=0, global_pool="avg"
        )
        feature_dim = int(self.backbone.num_features)
        self.head = nn.Sequential(
            nn.Linear(feature_dim, 512), nn.GELU(), nn.Dropout(0.2), nn.Linear(512, 1)
        )
        self.register_buffer("mean_tensor", torch.tensor((0.485, 0.456, 0.406)).view(1, 3, 1, 1))
        self.register_buffer("std_tensor", torch.tensor((0.229, 0.224, 0.225)).view(1, 3, 1, 1))

    def forward(self, images: torch.Tensor) -> dict[str, torch.Tensor]:
        features = self.backbone((images - self.mean_tensor) / self.std_tensor)
        return {"mean": self.head(features).squeeze(-1)}


class DistributionRegressor(nn.Module):
    def __init__(self, checkpoint: str) -> None:
        super().__init__()
        self.backbone = timm.create_model(
            checkpoint, pretrained=True, num_classes=0, global_pool="avg"
        )
        self.head = nn.Linear(int(self.backbone.num_features), 10)
        self.register_buffer("bins", torch.arange(1, 11, dtype=torch.float32))
        self.register_buffer("mean_tensor", torch.tensor((0.485, 0.456, 0.406)).view(1, 3, 1, 1))
        self.register_buffer("std_tensor", torch.tensor((0.229, 0.224, 0.225)).view(1, 3, 1, 1))

    def forward(self, images: torch.Tensor) -> dict[str, torch.Tensor]:
        normalized = (images - self.mean_tensor) / self.std_tensor
        distribution = torch.softmax(self.head(self.backbone(normalized)), dim=-1)
        mean = torch.sum(distribution * self.bins, dim=-1)
        return {"mean": mean, "distribution": distribution}


class CLIPMLPRegressor(nn.Module):
    mean = (0.48145466, 0.4578275, 0.40821073)
    std = (0.26862954, 0.26130258, 0.27577711)

    def __init__(self, checkpoint: str) -> None:
        super().__init__()
        self.backbone = CLIPVisionModel.from_pretrained(checkpoint)
        for parameter in self.backbone.parameters():
            parameter.requires_grad = False
        self.head = nn.Sequential(
            nn.Linear(1024, 512), nn.GELU(), nn.Dropout(0.2), nn.Linear(512, 1)
        )
        self.register_buffer("mean_tensor", torch.tensor(self.mean).view(1, 3, 1, 1))
        self.register_buffer("std_tensor", torch.tensor(self.std).view(1, 3, 1, 1))

    def forward(self, images: torch.Tensor) -> dict[str, torch.Tensor]:
        normalized = (images - self.mean_tensor) / self.std_tensor
        with torch.no_grad():
            features = self.backbone(pixel_values=normalized).pooler_output
        return {"mean": self.head(features).squeeze(-1)}


def build_baseline(settings: dict[str, Any]) -> nn.Module:
    family = str(settings["family"])
    checkpoint = str(settings["checkpoint"])
    if family == "timm_regressor":
        return TimmRegressor(checkpoint)
    if family == "distribution_regressor":
        return DistributionRegressor(checkpoint)
    if family == "clip_mlp":
        return CLIPMLPRegressor(checkpoint)
    raise ValueError(f"Unsupported baseline family: {family}")


def distribution_target(scores: torch.Tensor) -> torch.Tensor:
    clipped = scores.clamp(1.0, 10.0)
    lower = torch.floor(clipped).long().clamp(1, 10)
    upper = torch.ceil(clipped).long().clamp(1, 10)
    fraction = clipped - lower.float()
    target = torch.zeros(scores.shape[0], 10, device=scores.device, dtype=scores.dtype)
    target.scatter_add_(1, (lower - 1).unsqueeze(1), (1.0 - fraction).unsqueeze(1))
    target.scatter_add_(1, (upper - 1).unsqueeze(1), fraction.unsqueeze(1))
    return target


def baseline_loss(outputs: dict[str, torch.Tensor], target: torch.Tensor) -> torch.Tensor:
    if "distribution" not in outputs:
        return F.huber_loss(outputs["mean"], target, delta=1.0)
    expected = distribution_target(target)
    predicted_cdf = outputs["distribution"].cumsum(dim=-1)
    expected_cdf = expected.cumsum(dim=-1)
    return (predicted_cdf - expected_cdf).square().mean()
