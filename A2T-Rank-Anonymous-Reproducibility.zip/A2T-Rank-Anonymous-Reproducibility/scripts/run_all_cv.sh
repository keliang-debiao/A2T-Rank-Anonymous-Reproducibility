#!/usr/bin/env bash
set -euo pipefail

for seed in 2026 2027 2028 2029 2030; do
  bash scripts/run_seed.sh "$seed"
done
python scripts/aggregate_predictions.py --input-dir artifacts/predictions --output-dir artifacts/predictions

