from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
import torch
from torch.utils.data import DataLoader

from a2t_rank.config import load_yaml
from a2t_rank.data.dataset import APDDv2Dataset, category_mapping, load_partition
from a2t_rank.metrics import regression_metrics
from a2t_rank.models import A2TRank
from a2t_rank.prediction import predict_loader, save_predictions
from a2t_rank.utils import write_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate the frozen corruption protocol")
    parser.add_argument("--config", type=Path, default=Path("configs/a2t_rank.yaml"))
    parser.add_argument("--robustness-config", type=Path, default=Path("configs/robustness.yaml"))
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--prompt-bank", type=Path, required=True)
    parser.add_argument("--fold", type=int, choices=range(1, 6), required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    arguments = parser.parse_args()
    config = load_yaml(arguments.config)
    conditions = load_yaml(arguments.robustness_config)["conditions"]
    manifest_path = Path(config["data"]["manifest"])
    split_path = Path(config["data"]["split_dir"]) / f"outer_fold_{arguments.fold}.csv"
    manifest = pd.read_csv(manifest_path)
    categories = category_mapping(manifest)
    test_table = load_partition(manifest_path, split_path, "test")
    payload = torch.load(arguments.prompt_bank, map_location="cpu", weights_only=True)
    prompts = payload["queries"] if isinstance(payload, dict) else payload
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = A2TRank(config, prompts).to(device)
    checkpoint = torch.load(arguments.checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model_state"])
    results = {}
    clean_srocc = None
    for name, condition in conditions.items():
        corruption = condition or None
        dataset = APDDv2Dataset(
            test_table,
            Path(config["data"]["image_root"]),
            categories,
            training=False,
            image_size=int(config["experiment"]["image_size"]),
            corruption=corruption,
        )
        loader = DataLoader(
            dataset,
            batch_size=int(config["train"]["batch_size"]),
            shuffle=False,
            num_workers=int(config["train"]["num_workers"]),
            pin_memory=True,
        )
        predictions = predict_loader(model, loader, device, bool(config["train"]["amp"]))
        metrics = regression_metrics(predictions["y_true"], predictions["y_pred"])
        if name == "clean":
            clean_srocc = metrics["srocc"]
        if clean_srocc is None:
            raise RuntimeError("The clean condition must be evaluated first")
        metrics["retention"] = metrics["srocc"] / clean_srocc
        results[name] = metrics
        save_predictions(
            predictions,
            arguments.output_dir / f"{name}_seed{arguments.seed}_fold{arguments.fold}.csv",
        )
    write_json(
        arguments.output_dir / f"metrics_seed{arguments.seed}_fold{arguments.fold}.json",
        {"status": "executed", "conditions": results},
    )
    print(results)


if __name__ == "__main__":
    main()
