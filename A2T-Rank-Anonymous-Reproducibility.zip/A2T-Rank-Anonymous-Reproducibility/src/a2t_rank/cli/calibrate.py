from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from a2t_rank.calibration import fit_affine_calibration
from a2t_rank.utils import write_json


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Fit fold-local affine mean and log-variance calibration"
    )
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    table = pd.read_csv(arguments.predictions)
    calibration = fit_affine_calibration(
        table["y_true"].to_numpy(), table["y_pred"].to_numpy(), table["logvar"].to_numpy()
    )
    write_json(arguments.output, calibration.to_dict())
    print(calibration.to_dict())


if __name__ == "__main__":
    main()
